-- phpMyAdmin SQL Dump
-- version 2.9.1.1-Debian-2ubuntu1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Aug 06, 2007 at 11:18 AM
-- Server version: 5.0.38
-- PHP Version: 5.2.1
-- 
-- Database: `imobiliarias`
-- 

create database imobiliarias;
grant all privileges on imobiliarias.* to imobiliarias@localhost identified by 'imobiliarias';

-- --------------------------------------------------------

-- 
-- Table structure for table `fotos`
-- 

CREATE TABLE `fotos` (
  `id` int(11) NOT NULL auto_increment,
  `imovel_id` int(11) NOT NULL,
  `arquivo` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `imovel_id` (`imovel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

-- 
-- Dumping data for table `fotos`
-- 

INSERT INTO `fotos` (`id`, `imovel_id`, `arquivo`) VALUES 
(4, 2, 'casa1.jpg'),
(5, 2, 'casa2.jpg'),
(6, 3, 'casa3.jpg'),
(7, 3, 'casa4.jpg'),
(8, 4, 'casa5.jpg'),
(9, 4, 'casa6.jpg'),
(10, 5, 'casa7.jpg'),
(11, 5, 'casa8.jpg'),
(12, 6, 'casa9.jpg'),
(13, 6, 'casa10.jpg'),
(14, 7, 'casa11.jpg'),
(15, 7, 'casa12.jpg'),
(16, 8, 'casa13.jpg'),
(17, 8, 'casa14.jpg'),
(18, 9, 'casa15.jpg'),
(19, 9, 'casa16.jpg'),
(20, 10, 'casa17.jpg'),
(21, 10, 'casa18.jpg'),
(22, 11, 'casa19.jpg'),
(23, 11, 'casa20.jpg');

-- --------------------------------------------------------

-- 
-- Table structure for table `imobiliarias`
-- 

CREATE TABLE `imobiliarias` (
  `id` int(11) NOT NULL auto_increment,
  `nome` varchar(100) NOT NULL,
  `endereco` varchar(100) NOT NULL,
  `telefone` varchar(100) NOT NULL,
  `celular` varchar(100) default NULL,
  `email` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

-- 
-- Dumping data for table `imobiliarias`
-- 

INSERT INTO `imobiliarias` (`id`, `nome`, `endereco`, `telefone`, `celular`, `email`) VALUES 
(1, 'ImobiliÃ¡ria Temporeal', 'Rua XX', '55555', '22222', 'imobiliaria@temporeal.com.br'),
(4, 'NostraCasa', 'Rua Quintino BocaiÃºva', '33235555', NULL, 'email@nostracasa.com.br'),
(5, 'Markize', 'Rua GetÃºlio Vargas', '332366666', '99118877', 'email@markize.com.br'),
(6, 'iojhiojoi', 'kkk', '1111', '99', 'lslsl@lsls.com'),
(7, 'kkkk', 'kkk', '999', NULL, 'lslsl@lsls.com');

-- --------------------------------------------------------

-- 
-- Table structure for table `imovels`
-- 

CREATE TABLE `imovels` (
  `id` int(11) NOT NULL auto_increment,
  `imobiliaria_id` int(11) NOT NULL,
  `descricao` varchar(100) NOT NULL,
  `localizacao` varchar(100) NOT NULL,
  `quartos` varchar(100) NOT NULL,
  `garagem` varchar(100) NOT NULL,
  `valor` float NOT NULL,
  `proprietario` varchar(100) NOT NULL,
  `data_cadastro` date NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `imobiliaria_id` (`imobiliaria_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

-- 
-- Dumping data for table `imovels`
-- 

INSERT INTO `imovels` (`id`, `imobiliaria_id`, `descricao`, `localizacao`, `quartos`, `garagem`, `valor`, `proprietario`, `data_cadastro`) VALUES 
(2, 1, 'Imovel 1', 'LocalizaÃ§Ã£o 1', '1', 'S', 100000, 'ProprietÃ¡rio 1', '2007-07-27'),
(3, 1, 'Imovel 2', 'LocalizaÃ§Ã£o 2', '1', 'S', 100000, 'ProprietÃ¡rio 2', '2007-07-27'),
(4, 1, 'Imovel 3', 'LocalizaÃ§Ã£o 3', '1', 'S', 100000, 'ProprietÃ¡rio 3', '2007-07-27'),
(5, 1, 'Imovel 4', 'LocalizaÃ§Ã£o 4', '1', 'S', 100000, 'ProprietÃ¡rio 4', '2007-07-27'),
(6, 1, 'Imovel 5', 'LocalizaÃ§Ã£o 5', '1', 'S', 100000, 'ProprietÃ¡rio 5', '2007-07-27'),
(7, 1, 'Imovel 6', 'LocalizaÃ§Ã£o 6', '1', 'S', 100000, 'ProprietÃ¡rio 6', '2007-07-27'),
(8, 1, 'Imovel 7', 'LocalizaÃ§Ã£o 7', '1', 'S', 100000, 'ProprietÃ¡rio 7', '2007-07-27'),
(9, 1, 'Imovel 8', 'LocalizaÃ§Ã£o 8', '1', 'S', 100000, 'ProprietÃ¡rio 8', '2007-07-27'),
(10, 1, 'Imovel 9', 'LocalizaÃ§Ã£o 9', '1', 'S', 100000, 'ProprietÃ¡rio 9', '2007-07-27'),
(11, 1, 'Imovel 10', 'LocalizaÃ§Ã£o 10', '1', 'S', 100000, 'ProprietÃ¡rio 10', '2007-07-27');

-- --------------------------------------------------------

-- 
-- Table structure for table `interessados`
-- 

CREATE TABLE `interessados` (
  `id` int(11) NOT NULL auto_increment,
  `imovel_id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `telefone` varchar(100) NOT NULL,
  `celular` varchar(100) default NULL,
  `email` varchar(100) default NULL,
  PRIMARY KEY  (`id`),
  KEY `imovel_id` (`imovel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `interessados`
-- 

INSERT INTO `interessados` (`id`, `imovel_id`, `nome`, `telefone`, `celular`, `email`) VALUES 
(1, 2, 'Elton Minetto', '7777', '999', 'ssl@lsls.com'),
(2, 2, 'elton', '999', '999', 'slsl@com.br'),
(3, 2, 'kkk', 'kk', 'kk', 'kk@lsl.comn');

-- --------------------------------------------------------

-- 
-- Table structure for table `usuarios`
-- 

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL auto_increment,
  `imobiliaria_id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `senha` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `imobiliaria_id` (`imobiliaria_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `usuarios`
-- 

INSERT INTO `usuarios` (`id`, `imobiliaria_id`, `nome`, `email`, `senha`) VALUES 
(1, 1, 'elton', 'eminetto@gmail.com', '1234');

-- 
-- Constraints for dumped tables
-- 

-- 
-- Constraints for table `fotos`
-- 
ALTER TABLE `fotos`
  ADD CONSTRAINT `fotos_ibfk_1` FOREIGN KEY (`imovel_id`) REFERENCES `imovels` (`id`);

-- 
-- Constraints for table `imovels`
-- 
ALTER TABLE `imovels`
  ADD CONSTRAINT `imovels_ibfk_1` FOREIGN KEY (`imobiliaria_id`) REFERENCES `imobiliarias` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- 
-- Constraints for table `interessados`
-- 
ALTER TABLE `interessados`
  ADD CONSTRAINT `interessados_ibfk_1` FOREIGN KEY (`imovel_id`) REFERENCES `imovels` (`id`);

-- 
-- Constraints for table `usuarios`
-- 
ALTER TABLE `usuarios`
  ADD CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`imobiliaria_id`) REFERENCES `imobiliarias` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

