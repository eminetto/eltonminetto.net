<?php
class InteressadosController extends AppController {

	var $name = 'Interessados';
	var $helpers = array('Html', 'Form' , 'Javascript');

	function index() {
		$this->Interessado->recursive = 0;
		$this->set('interessados', $this->Interessado->findAll());
	}

	function view($id = null) {
		if(!$id) {
			$this->Session->setFlash('Invalid id for Interessado.');
			$this->redirect('/interessados/index');
		}
		$this->set('interessado', $this->Interessado->read(null, $id));
	}

	function add() {
		if(empty($this->data)) {
			$this->set('imovels', $this->Interessado->Imovel->generateList());
			$this->render();
		} else {
			$this->cleanUpFields();
			if($this->Interessado->save($this->data)) {
				$this->Session->setFlash('The Interessado has been saved');
				$this->redirect('/imobiliarias/index');
			} else {
				$this->Session->setFlash('Please correct errors below.');
				$this->set('imovels', $this->Interessado->Imovel->generateList());
			}
		}
	}

	function edit($id = null) {
		if(empty($this->data)) {
			if(!$id) {
				$this->Session->setFlash('Invalid id for Interessado');
				$this->redirect('/interessados/index');
			}
			$this->data = $this->Interessado->read(null, $id);
			$this->set('imovels', $this->Interessado->Imovel->generateList());
		} else {
			$this->cleanUpFields();
			if($this->Interessado->save($this->data)) {
				$this->Session->setFlash('The Interessado has been saved');
				$this->redirect('/interessados/index');
			} else {
				$this->Session->setFlash('Please correct errors below.');
				$this->set('imovels', $this->Interessado->Imovel->generateList());
			}
		}
	}

	function delete($id = null) {
		if(!$id) {
			$this->Session->setFlash('Invalid id for Interessado');
			$this->redirect('/interessados/index');
		}
		if($this->Interessado->del($id)) {
			$this->Session->setFlash('The Interessado deleted: id '.$id.'');
			$this->redirect('/interessados/index');
		}
	}


	function admin_index() {
		$this->Interessado->recursive = 0;
		$this->set('interessados', $this->Interessado->findAll());
	}

	function admin_view($id = null) {
		if(!$id) {
			$this->Session->setFlash('Invalid id for Interessado.');
			$this->redirect('/admin/interessados/index');
		}
		$this->set('interessado', $this->Interessado->read(null, $id));
	}

	function admin_add() {
		if(empty($this->data)) {
			$this->set('imovels', $this->Interessado->Imovel->generateList());
			$this->render();
		} else {
			$this->cleanUpFields();
			if($this->Interessado->save($this->data)) {
				$this->Session->setFlash('The Interessado has been saved');
				$this->redirect('/admin/interessados/index');
			} else {
				$this->Session->setFlash('Please correct errors below.');
				$this->set('imovels', $this->Interessado->Imovel->generateList());
			}
		}
	}

	function admin_edit($id = null) {
		if(empty($this->data)) {
			if(!$id) {
				$this->Session->setFlash('Invalid id for Interessado');
				$this->redirect('/admin/interessados/index');
			}
			$this->data = $this->Interessado->read(null, $id);
			$this->set('imovels', $this->Interessado->Imovel->generateList());
		} else {
			$this->cleanUpFields();
			if($this->Interessado->save($this->data)) {
				$this->Session->setFlash('The Interessado has been saved');
				$this->redirect('/admin/interessados/index');
			} else {
				$this->Session->setFlash('Please correct errors below.');
				$this->set('imovels', $this->Interessado->Imovel->generateList());
			}
		}
	}

	function admin_delete($id = null) {
		if(!$id) {
			$this->Session->setFlash('Invalid id for Interessado');
			$this->redirect('/admin/interessados/index');
		}
		if($this->Interessado->del($id)) {
			$this->Session->setFlash('The Interessado deleted: id '.$id.'');
			$this->redirect('/admin/interessados/index');
		}
	}

}
?>
