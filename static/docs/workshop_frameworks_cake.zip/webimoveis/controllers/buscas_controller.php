<?php
class BuscasController extends AppController 
{
	var $name = 'Buscas'; //nome do controlador
	var $helpers = array('Html',  'Ajax' ); //uso dos helpers
	var $uses = array("Imovel"); //indica qual modelo usar

	//funcao da pagina inicial
	function index() {
	}
	
	//funcao que sera executada por AJAX para retornar os livros 
	function update () 	{
		//pega o parametro enviado pelo formulário
		$consulta = $this->params["form"]["localizacao"]."%"; 
		$this->set('imovels',$this->Imovel->findAll("Imovel.localizacao LIKE '$consulta'")); //executa a consulta
		//queremos usar o layout de ajax e não html
		$this->layout = "ajax";  
	}
}
?>