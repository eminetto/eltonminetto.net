<?php
class FotosController extends AppController {

	var $name = 'Fotos';
	var $helpers = array('Html', 'Form' , 'Javascript');

	function index() {
		$this->Foto->recursive = 0;
		$this->set('fotos', $this->Foto->findAll());
	}

	function view($id = null) {
		if(!$id) {
			$this->Session->setFlash('Invalid id for Foto.');
			$this->redirect('/fotos/index');
		}
		$this->set('foto', $this->Foto->read(null, $id));
	}

	function add() {
		if(empty($this->data)) {
			$this->set('imovels', $this->Foto->Imovel->generateList());
			$this->render();
		} else {
			$this->cleanUpFields();
			if($this->Foto->save($this->data)) {
				$this->Session->setFlash('The Foto has been saved');
				$this->redirect('/fotos/index');
			} else {
				$this->Session->setFlash('Please correct errors below.');
				$this->set('imovels', $this->Foto->Imovel->generateList());
			}
		}
	}

	function edit($id = null) {
		if(empty($this->data)) {
			if(!$id) {
				$this->Session->setFlash('Invalid id for Foto');
				$this->redirect('/fotos/index');
			}
			$this->data = $this->Foto->read(null, $id);
			$this->set('imovels', $this->Foto->Imovel->generateList());
		} else {
			$this->cleanUpFields();
			if($this->Foto->save($this->data)) {
				$this->Session->setFlash('The Foto has been saved');
				$this->redirect('/fotos/index');
			} else {
				$this->Session->setFlash('Please correct errors below.');
				$this->set('imovels', $this->Foto->Imovel->generateList());
			}
		}
	}

	function delete($id = null) {
		if(!$id) {
			$this->Session->setFlash('Invalid id for Foto');
			$this->redirect('/fotos/index');
		}
		if($this->Foto->del($id)) {
			$this->Session->setFlash('The Foto deleted: id '.$id.'');
			$this->redirect('/fotos/index');
		}
	}


	function admin_index() {
		$this->Foto->recursive = 0;
		$this->set('fotos', $this->Foto->findAll());
	}

	function admin_view($id = null) {
		if(!$id) {
			$this->Session->setFlash('Invalid id for Foto.');
			$this->redirect('/admin/fotos/index');
		}
		$this->set('foto', $this->Foto->read(null, $id));
	}

	function admin_add() {
		if(empty($this->data)) {
			$this->set('imovels', $this->Foto->Imovel->generateList());
			$this->render();
		} else {
			$this->cleanUpFields();
	//upload do arquivo
			if(isset($this->data['Foto']['arquivo']['tmp_name'])) {
				//copiando o arquivo para o diretorio final
				copy($this->data['Foto']['arquivo']['tmp_name'],"/var/www/xxe/webimoveis/webroot/img/".$this->data['Foto']['arquivo']['name']);
				//substitui o campo arquivo por somente o nome do arquivo
				$this->data['Foto']['arquivo'] = $this->data['Foto']['arquivo']['name'];
			}			

		if($this->Foto->save($this->data)) {
				$this->Session->setFlash('The Foto has been saved');
				$this->redirect('/admin/fotos/index');
			} else {
				$this->Session->setFlash('Please correct errors below.');
				$this->set('imovels', $this->Foto->Imovel->generateList());
			}
		}
	}

	function admin_edit($id = null) {
		if(empty($this->data)) {
			if(!$id) {
				$this->Session->setFlash('Invalid id for Foto');
				$this->redirect('/admin/fotos/index');
			}
			$this->data = $this->Foto->read(null, $id);
			$this->set('imovels', $this->Foto->Imovel->generateList());
		} else {
			$this->cleanUpFields();
			if($this->Foto->save($this->data)) {
				$this->Session->setFlash('The Foto has been saved');
				$this->redirect('/admin/fotos/index');
			} else {
				$this->Session->setFlash('Please correct errors below.');
				$this->set('imovels', $this->Foto->Imovel->generateList());
			}
		}
	}

	function admin_delete($id = null) {
		if(!$id) {
			$this->Session->setFlash('Invalid id for Foto');
			$this->redirect('/admin/fotos/index');
		}
		if($this->Foto->del($id)) {
			$this->Session->setFlash('The Foto deleted: id '.$id.'');
			$this->redirect('/admin/fotos/index');
		}
	}

}
?>
