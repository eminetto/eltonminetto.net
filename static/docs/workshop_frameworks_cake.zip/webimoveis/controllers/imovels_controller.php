<?php
class ImovelsController extends AppController {

	var $name = 'Imovels';
	var $helpers = array('Html', 'Form' , 'Javascript');

	function index() {
		$this->Imovel->recursive = 0;
		$this->set('imovels', $this->Imovel->findAll());
	}


	function admin_index() {
		$this->Imovel->recursive = 1;
		$this->set('imovels', $this->Imovel->findAll());
	}

	function admin_view($id = null) {
		if(!$id) {
			$this->Session->setFlash('Invalid id for Imovel.');
			$this->redirect('/admin/imovels/index');
		}
		$this->set('imovel', $this->Imovel->read(null, $id));
	}

	function admin_add() {
		if(empty($this->data)) {
			$this->set('imobiliarias', $this->Imovel->Imobiliaria->generateList());
			$this->render();
		} else {
			$this->cleanUpFields();
			if($this->Imovel->save($this->data)) {
				$this->Session->setFlash('The Imovel has been saved');
				$this->redirect('/admin/imovels/index');
			} else {
				$this->Session->setFlash('Please correct errors below.');
				$this->set('imobiliarias', $this->Imovel->Imobiliaria->generateList());
			}
		}
	}

	function admin_edit($id = null) {
		if(empty($this->data)) {
			if(!$id) {
				$this->Session->setFlash('Invalid id for Imovel');
				$this->redirect('/admin/imovels/index');
			}
			$this->data = $this->Imovel->read(null, $id);
			$this->set('imobiliarias', $this->Imovel->Imobiliaria->generateList());
		} else {
			$this->cleanUpFields();
			if($this->Imovel->save($this->data)) {
				$this->Session->setFlash('The Imovel has been saved');
				$this->redirect('/admin/imovels/index');
			} else {
				$this->Session->setFlash('Please correct errors below.');
				$this->set('imobiliarias', $this->Imovel->Imobiliaria->generateList());
			}
		}
	}

	function admin_delete($id = null) {
		if(!$id) {
			$this->Session->setFlash('Invalid id for Imovel');
			$this->redirect('/admin/imovels/index');
		}
		if($this->Imovel->del($id)) {
			$this->Session->setFlash('The Imovel deleted: id '.$id.'');
			$this->redirect('/admin/imovels/index');
		}
	}

}
?>
