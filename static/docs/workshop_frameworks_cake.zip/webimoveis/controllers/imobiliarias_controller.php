<?php
class ImobiliariasController extends AppController {

	var $name = 'Imobiliarias';
	var $helpers = array('Html', 'Form' , 'Javascript');

	function index($id=null) {
		//busca as imobiliarias
		$this->Imobiliaria->recursive = 0; //não recursivo. busca só a imobiliária
		$this->set('imobiliarias',$this->Imobiliaria->findAll());
		//busca a imobiliaria atual
		if($id) { //se já foi selecionado uma, deve buscar todos os dados
			$this->Imobiliaria->recursive = 2;
			$this->set('atual', $this->Imobiliaria->findAllById($id));
		}
	}

	function admin_index() {
		$this->Imobiliaria->recursive = 0;
		$this->set('imobiliarias', $this->Imobiliaria->findAll());
	}

	function admin_view($id = null) {
		if(!$id) {
			$this->Session->setFlash('Invalid id for Imobiliaria.');
			$this->redirect('/admin/imobiliarias/index');
		}
		$this->set('imobiliaria', $this->Imobiliaria->read(null, $id));
	}

	function admin_add() {
		if(empty($this->data)) {
			$this->render();
		} else {
			$this->cleanUpFields();
			if($this->Imobiliaria->save($this->data)) {
				$this->Session->setFlash('The Imobiliaria has been saved');
				$this->redirect('/admin/imobiliarias/index');
			} else {
				$this->Session->setFlash('Please correct errors below.');
			}
		}
	}

	function admin_edit($id = null) {
		if(empty($this->data)) {
			if(!$id) {
				$this->Session->setFlash('Invalid id for Imobiliaria');
				$this->redirect('/admin/imobiliarias/index');
			}
			$this->data = $this->Imobiliaria->read(null, $id);
		} else {
			$this->cleanUpFields();
			if($this->Imobiliaria->save($this->data)) {
				$this->Session->setFlash('The Imobiliaria has been saved');
				$this->redirect('/admin/imobiliarias/index');
			} else {
				$this->Session->setFlash('Please correct errors below.');
			}
		}
	}

	function admin_delete($id = null) {
		if(!$id) {
			$this->Session->setFlash('Invalid id for Imobiliaria');
			$this->redirect('/admin/imobiliarias/index');
		}
		if($this->Imobiliaria->del($id)) {
			$this->Session->setFlash('The Imobiliaria deleted: id '.$id.'');
			$this->redirect('/admin/imobiliarias/index');
		}
	}

}
?>
