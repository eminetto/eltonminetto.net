<?php
class LoginController extends AppController {
	var $name = 'Login';
	var $helpers = array('Html','Form','Javascript');
	var $uses = array('Usuario');
	
	//mostra o formulario de login
	function index() {
		//verifica se já foi feito o login
		if($this->Session->check('logado'))
			$this->redirect('/login/menu');
	}
	
	//faz a validação
	function valida() {
		//limpa os dados vindos do formulario. Segurança
		uses('sanitize');
		$clean = new Sanitize();
		$clean->cleanArray($this->data);
		//pega os dados do formulario
		$email = $this->data['login']['email'];
		$senha = $this->data['login']['senha'];
		//busca o usuario
		$usuario = $this->Usuario->findByEmail($email);
		if(!empty($usuario) && $usuario['Usuario']['senha'] == $senha) {
			//escreve na seçao
			$this->Session->write('logado',$email);
			//redireciona para o menu
			$this->redirect('/login/menu');
		}
		else {
			//dados incorretos
			$this->Session->setFlash('Usuário ou senha inválidos');
			$this->redirect('/login');
		}
	}
	
	//funcao que faz o logout
	function logout() {
		$this->Session->delete('logado');
		$this->redirect('/imobiliarias');
	}
	
	//funcao que monta o menu
	function menu() {
	}
}
?>