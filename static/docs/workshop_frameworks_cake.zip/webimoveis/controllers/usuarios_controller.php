<?php
class UsuariosController extends AppController {

	var $name = 'Usuarios';
	var $helpers = array('Html', 'Form' , 'Javascripy');

	function index() {
		$this->Usuario->recursive = 0;
		$this->set('usuarios', $this->Usuario->findAll());
	}

	function view($id = null) {
		if(!$id) {
			$this->Session->setFlash('Invalid id for Usuario.');
			$this->redirect('/usuarios/index');
		}
		$this->set('usuario', $this->Usuario->read(null, $id));
	}

	function add() {
		if(empty($this->data)) {
			$this->set('imobiliarias', $this->Usuario->Imobiliaria->generateList());
			$this->render();
		} else {
			$this->cleanUpFields();
			if($this->Usuario->save($this->data)) {
				$this->Session->setFlash('The Usuario has been saved');
				$this->redirect('/usuarios/index');
			} else {
				$this->Session->setFlash('Please correct errors below.');
				$this->set('imobiliarias', $this->Usuario->Imobiliaria->generateList());
			}
		}
	}

	function edit($id = null) {
		if(empty($this->data)) {
			if(!$id) {
				$this->Session->setFlash('Invalid id for Usuario');
				$this->redirect('/usuarios/index');
			}
			$this->data = $this->Usuario->read(null, $id);
			$this->set('imobiliarias', $this->Usuario->Imobiliaria->generateList());
		} else {
			$this->cleanUpFields();
			if($this->Usuario->save($this->data)) {
				$this->Session->setFlash('The Usuario has been saved');
				$this->redirect('/usuarios/index');
			} else {
				$this->Session->setFlash('Please correct errors below.');
				$this->set('imobiliarias', $this->Usuario->Imobiliaria->generateList());
			}
		}
	}

	function delete($id = null) {
		if(!$id) {
			$this->Session->setFlash('Invalid id for Usuario');
			$this->redirect('/usuarios/index');
		}
		if($this->Usuario->del($id)) {
			$this->Session->setFlash('The Usuario deleted: id '.$id.'');
			$this->redirect('/usuarios/index');
		}
	}


	function admin_index() {
		$this->Usuario->recursive = 0;
		$this->set('usuarios', $this->Usuario->findAll());
	}

	function admin_view($id = null) {
		if(!$id) {
			$this->Session->setFlash('Invalid id for Usuario.');
			$this->redirect('/admin/usuarios/index');
		}
		$this->set('usuario', $this->Usuario->read(null, $id));
	}

	function admin_add() {
		if(empty($this->data)) {
			$this->set('imobiliarias', $this->Usuario->Imobiliaria->generateList());
			$this->render();
		} else {
			$this->cleanUpFields();
			if($this->Usuario->save($this->data)) {
				$this->Session->setFlash('The Usuario has been saved');
				$this->redirect('/admin/usuarios/index');
			} else {
				$this->Session->setFlash('Please correct errors below.');
				$this->set('imobiliarias', $this->Usuario->Imobiliaria->generateList());
			}
		}
	}

	function admin_edit($id = null) {
		if(empty($this->data)) {
			if(!$id) {
				$this->Session->setFlash('Invalid id for Usuario');
				$this->redirect('/admin/usuarios/index');
			}
			$this->data = $this->Usuario->read(null, $id);
			$this->set('imobiliarias', $this->Usuario->Imobiliaria->generateList());
		} else {
			$this->cleanUpFields();
			if($this->Usuario->save($this->data)) {
				$this->Session->setFlash('The Usuario has been saved');
				$this->redirect('/admin/usuarios/index');
			} else {
				$this->Session->setFlash('Please correct errors below.');
				$this->set('imobiliarias', $this->Usuario->Imobiliaria->generateList());
			}
		}
	}

	function admin_delete($id = null) {
		if(!$id) {
			$this->Session->setFlash('Invalid id for Usuario');
			$this->redirect('/admin/usuarios/index');
		}
		if($this->Usuario->del($id)) {
			$this->Session->setFlash('The Usuario deleted: id '.$id.'');
			$this->redirect('/admin/usuarios/index');
		}
	}

}
?>