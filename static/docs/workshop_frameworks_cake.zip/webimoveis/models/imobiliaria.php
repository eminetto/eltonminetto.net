<?php
class Imobiliaria extends AppModel {

	var $name = 'Imobiliaria';
	var $validate = array(
		'id' => VALID_NOT_EMPTY,
		'nome' => VALID_NOT_EMPTY,
		'telefone' => VALID_NOT_EMPTY,
		'email' => VALID_EMAIL,
	);

	//The Associations below have been created with all possible keys, those that are not needed can be removed
	var $hasMany = array(
			'Imovel' =>
				array('className' => 'Imovel',
						'foreignKey' => 'imobiliaria_id',
						'conditions' => '',
						'fields' => '',
						'order' => '',
						'limit' => '',
						'offset' => '',
						'dependent' => '',
						'exclusive' => '',
						'finderQuery' => '',
						'counterQuery' => ''
				),

			'Usuario' =>
				array('className' => 'Usuario',
						'foreignKey' => 'imobiliaria_id',
						'conditions' => '',
						'fields' => '',
						'order' => '',
						'limit' => '',
						'offset' => '',
						'dependent' => '',
						'exclusive' => '',
						'finderQuery' => '',
						'counterQuery' => ''
				),

	);

}
?>