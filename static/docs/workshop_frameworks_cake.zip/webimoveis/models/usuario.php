<?php
class Usuario extends AppModel {

	var $name = 'Usuario';

	//The Associations below have been created with all possible keys, those that are not needed can be removed
	var $belongsTo = array(
			'Imobiliaria' =>
				array('className' => 'Imobiliaria',
						'foreignKey' => 'imobiliaria_id',
						'conditions' => '',
						'fields' => '',
						'order' => '',
						'counterCache' => ''
				),

	);

}
?>