<?php
class Imovel extends AppModel {

	var $name = 'Imovel';
	var $validate = array(
		'id' => VALID_NOT_EMPTY,
		'imobiliaria_id' => VALID_NOT_EMPTY,
		'descricao' => VALID_NOT_EMPTY,
		'localizacao' => VALID_NOT_EMPTY,
		'quartos' => VALID_NOT_EMPTY,
		'valor' => VALID_NOT_EMPTY,
		'data_cadastro' => VALID_NOT_EMPTY,
	);

	//The Associations below have been created with all possible keys, those that are not needed can be removed
	var $belongsTo = array(
			'Imobiliaria' =>
				array('className' => 'Imobiliaria',
						'foreignKey' => 'imobiliaria_id',
						'conditions' => '',
						'fields' => '',
						'order' => '',
						'counterCache' => ''
				),

	);

	var $hasMany = array(
			'Foto' =>
				array('className' => 'Foto',
						'foreignKey' => 'imovel_id',
						'conditions' => '',
						'fields' => '',
						'order' => '',
						'limit' => '',
						'offset' => '',
						'dependent' => '',
						'exclusive' => '',
						'finderQuery' => '',
						'counterQuery' => ''
				),

			'Interessado' =>
				array('className' => 'Interessado',
						'foreignKey' => 'imovel_id',
						'conditions' => '',
						'fields' => '',
						'order' => '',
						'limit' => '',
						'offset' => '',
						'dependent' => '',
						'exclusive' => '',
						'finderQuery' => '',
						'counterQuery' => ''
				),

	);

}
?>