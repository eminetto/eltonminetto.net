function abreFoto(foto){
	var div = document.getElementById('OfertaFotoGrande');
	div.style.visibility = 'visible';
}
function fecharFoto(){
	var div = document.getElementById('OfertaFotoGrande');
	div.style.visibility = 'hidden';
}