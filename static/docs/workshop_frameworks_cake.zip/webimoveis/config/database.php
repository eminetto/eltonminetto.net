<?php
class DATABASE_CONFIG {

	var $default = array(
		'driver' => 'mysql',
		'connect' => 'mysql_connect',
		'host' => 'localhost',
		'login' => 'imobiliarias',
		'password' => 'imobiliarias',
		'database' => 'imobiliarias', 
		'prefix' => '' 
	);
}
?>