<?php
$id = 27;//$_GET['id'];
if($id % 2 == 0) { 
	$con = mysql_connect('localhost','root','root');
	mysql_select_db("sh_db1");
}
else {
	$con = mysql_connect('localhost','root','root');
	mysql_select_db("sh_db2");
}
$res = mysql_query("select * from post where autor_id=$id",$con);
while($conteudo = mysql_fetch_array($res, MYSQL_ASSOC)) 
	var_dump($conteudo);
