class Conta:
	SEM_SALDO = 'Sem saldo'
	NEGATIVO = 'Valor negativo'
	def __init__(self,numero, nome):
		self.numero = numero
		self.nome = nome
		self.saldo = 0
	
	def deposito(self,valor):
		self.saldo = self.saldo + valor
	
	def getSaldo(self):
		return self.saldo
	
	def saque(self,valor):
		if self.saldo == 0:
			raise self.SEM_SALDO
		elif self.saldo < valor:
			raise self.NEGATIVO
		else:
			self.saldo = self.saldo - valor
