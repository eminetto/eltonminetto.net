from javax.swing import *
janela = JFrame('Teste')
label = JLabel('Ola mundo!')
janela.getContentPane().add(label)
janela.setBounds(20,20,200,200)
janela.setVisible(1)
