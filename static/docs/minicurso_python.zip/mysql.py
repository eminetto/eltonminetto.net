import MySQLdb 
con = MySQLdb.connect('localhost', 'root', '')
con.select_db('financas')
cursor = con.cursor()
cursor.execute("select distinct nome_usu,email_usu from usuario where nome_usu like 'e%'")
linha = cursor.fetchall()
print linha
#for linha in cursor:
#	print "nome= %s e-mail= %s"  % (linha[0],linha[1])
cursor.close()
con.close()
