arq = open('lslsls.txt','r')
x = arq.readlines()
arq.close()
for i in x:
	try:
		x = x + 1
	except:
		print "erro"
		print "sei la"
	print "ok"

