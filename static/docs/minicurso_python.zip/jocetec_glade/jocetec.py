import gtk, gtk.glade, sys
def on_imprimir_clicked():
	t = gladefile.get_widget('texto')
	print t
	#print t.get_text()
def fechar():
	sys.exit()
dic = {"on_imprimir_clicked": on_imprimir_clicked, "destroy": fechar }
gladefile = gtk.glade.XML("jocetec.glade")
gladefile.signal_autoconnect(dic)
gtk.main()
