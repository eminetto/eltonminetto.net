import Tkinter
tela = Tkinter.Tk()
tela.title('Hello')
edit = Tkinter.Entry(tela)
label= Tkinter.Label(tela, text='Tkinter!!!!')
label.pack()
edit.pack()
tela.mainloop()
