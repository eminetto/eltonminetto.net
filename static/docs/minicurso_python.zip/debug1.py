# Importando o Modulo
import pdb
# Definindo as variaveis
nome       = "Elton"
sobrenome  = "Minetto"
# concatenando as variaveis
junto   = "Meu nome eh %s %s" %(nome,sobrenome)
# Imprimindo a variavel
print junto
# definindo o rastreamento
pdb.set_trace()
x = int(raw_input("digite um valor:"))
if x < 10:
	x = x + 1
	print x
else:
	x = x + 2 
	print x
