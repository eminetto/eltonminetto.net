class A:
	"""teste de teste"""
	atributo1 = 'atributo1 da classe A'
	atributo2 = 'atributo2 da classe A'
	def __init__(self, val_ini=1):
		"Construtor da classe A"
		self.atributo_de_instancia = val_ini
	def metodo(self):
		print self.atributo_de_instancia
		print A.atributo1

	def __doc__(self):
		"""lixo"""
		return "teste"
	def soma(self, x):
		return x  + 1
