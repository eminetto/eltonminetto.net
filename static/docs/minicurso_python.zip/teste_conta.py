from conta import *
import pdb
pdb.set_trace()
x = Conta(1,'elton')
x.deposito(100)
print x.getSaldo()
try:
	x.saque(200)
except Conta.NEGATIVO:
	print Conta.NEGATIVO
except Conta.SEM_SALDO:
	print Conta.SEM_SALDO
except:
	print "outro tipo de erro"
