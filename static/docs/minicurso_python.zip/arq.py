arq = open("teste.txt","r")
"""comentario 
de varias
linhas
"""
for i in arq.readlines():
	for j in i.split():
		print j
arq.close()
