var = int(raw_input("digite o numero "))
a = 4
if var == 10 and a == 4:
	print 'eh 10'
else:
	print 'nao eh 10'
	a = var + 1
	print a
print 'sempre'
