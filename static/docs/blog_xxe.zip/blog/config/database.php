<?php
class DATABASE_CONFIG {

	var $default = array(
		'driver' => 'mysql',
		'connect' => 'mysql_connect',
		'host' => 'localhost',
		'login' => 'blog',
		'password' => 'blog',
		'database' => 'blog', 
		'prefix' => '' 
	);
}
?>