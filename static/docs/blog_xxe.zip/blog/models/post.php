<?php
class Post extends AppModel {

	var $name = 'Post';
	var $validate = array(
		'id' => VALID_NOT_EMPTY,
		'blog_id' => VALID_NOT_EMPTY,
		'titulo' => VALID_NOT_EMPTY,
		'texto' => VALID_NOT_EMPTY,
	);

	//The Associations below have been created with all possible keys, those that are not needed can be removed
	var $belongsTo = array(
			'Blog' =>
				array('className' => 'Blog',
						'foreignKey' => 'blog_id',
						'conditions' => '',
						'fields' => '',
						'order' => '',
						'counterCache' => ''
				),

	);

	var $hasMany = array(
			'Comentario' =>
				array('className' => 'Comentario',
						'foreignKey' => 'post_id',
						'conditions' => '',
						'fields' => '',
						'order' => '',
						'limit' => '',
						'offset' => '',
						'dependent' => '',
						'exclusive' => '',
						'finderQuery' => '',
						'counterQuery' => ''
				),

	);

}
?>