<?php
class Comentario extends AppModel {

	var $name = 'Comentario';
	var $validate = array(
		'id' => VALID_NOT_EMPTY,
		'post_id' => VALID_NOT_EMPTY,
		'nome' => VALID_NOT_EMPTY,
		'email' => VALID_EMAIL,
		'texto' => VALID_NOT_EMPTY,
	);

	//The Associations below have been created with all possible keys, those that are not needed can be removed
	var $belongsTo = array(
			'Post' =>
				array('className' => 'Post',
						'foreignKey' => 'post_id',
						'conditions' => '',
						'fields' => '',
						'order' => '',
						'counterCache' => ''
				),

	);

}
?>