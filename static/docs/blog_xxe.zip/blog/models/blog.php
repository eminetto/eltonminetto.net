<?php
class Blog extends AppModel {

	var $name = 'Blog';
	var $validate = array(
		'id' => VALID_NOT_EMPTY,
		'nome' => VALID_NOT_EMPTY,
		'descricao' => VALID_NOT_EMPTY,
		'email' => VALID_EMAIL,
		'senha' => VALID_NOT_EMPTY,
	);

	//The Associations below have been created with all possible keys, those that are not needed can be removed
	var $hasMany = array(
			'Post' =>
				array('className' => 'Post',
						'foreignKey' => 'blog_id',
						'conditions' => '',
						'fields' => '',
						'order' => '',
						'limit' => '',
						'offset' => '',
						'dependent' => '',
						'exclusive' => '',
						'finderQuery' => '',
						'counterQuery' => ''
				),

	);

}
?>