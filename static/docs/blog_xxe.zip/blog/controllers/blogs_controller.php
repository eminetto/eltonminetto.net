<?php
class BlogsController extends AppController {

	var $name = 'Blogs';
	var $helpers = array('Html', 'Form' );

	function index() {
		$this->Blog->recursive = 0;
		$this->set('blogs', $this->Blog->findAll());
	}

	function view($id = null) {
		if(!$id) {
			$this->Session->setFlash('Invalid id for Blog.');
			$this->redirect('/blogs/index');
		}
		$this->set('blog', $this->Blog->read(null, $id));
	}

	function add() {
		if(empty($this->data)) {
			$this->render();
		} else {
			$this->cleanUpFields();
			if($this->Blog->save($this->data)) {
				$this->Session->setFlash('The Blog has been saved');
				$this->redirect('/blogs/index');
			} else {
				$this->Session->setFlash('Please correct errors below.');
			}
		}
	}

	function edit($id = null) {
		if(empty($this->data)) {
			if(!$id) {
				$this->Session->setFlash('Invalid id for Blog');
				$this->redirect('/blogs/index');
			}
			$this->data = $this->Blog->read(null, $id);
		} else {
			$this->cleanUpFields();
			if($this->Blog->save($this->data)) {
				$this->Session->setFlash('The Blog has been saved');
				$this->redirect('/blogs/index');
			} else {
				$this->Session->setFlash('Please correct errors below.');
			}
		}
	}

	function delete($id = null) {
		if(!$id) {
			$this->Session->setFlash('Invalid id for Blog');
			$this->redirect('/blogs/index');
		}
		if($this->Blog->del($id)) {
			$this->Session->setFlash('The Blog deleted: id '.$id.'');
			$this->redirect('/blogs/index');
		}
	}


	function admin_index() {
		$this->Blog->recursive = 0;
		$this->set('blogs', $this->Blog->findAll());
	}

	function admin_view($id = null) {
		if(!$id) {
			$this->Session->setFlash('Invalid id for Blog.');
			$this->redirect('/admin/blogs/index');
		}
		$this->set('blog', $this->Blog->read(null, $id));
	}

	function admin_add() {
		if(empty($this->data)) {
			$this->render();
		} else {
			$this->cleanUpFields();
			if($this->Blog->save($this->data)) {
				$this->Session->setFlash('The Blog has been saved');
				$this->redirect('/admin/blogs/index');
			} else {
				$this->Session->setFlash('Please correct errors below.');
			}
		}
	}

	function admin_edit($id = null) {
		if(empty($this->data)) {
			if(!$id) {
				$this->Session->setFlash('Invalid id for Blog');
				$this->redirect('/admin/blogs/index');
			}
			$this->data = $this->Blog->read(null, $id);
		} else {
			$this->cleanUpFields();
			if($this->Blog->save($this->data)) {
				$this->Session->setFlash('The Blog has been saved');
				$this->redirect('/admin/blogs/index');
			} else {
				$this->Session->setFlash('Please correct errors below.');
			}
		}
	}

	function admin_delete($id = null) {
		if(!$id) {
			$this->Session->setFlash('Invalid id for Blog');
			$this->redirect('/admin/blogs/index');
		}
		if($this->Blog->del($id)) {
			$this->Session->setFlash('The Blog deleted: id '.$id.'');
			$this->redirect('/admin/blogs/index');
		}
	}

}
?>