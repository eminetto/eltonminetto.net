<?php
class AuthController extends AppController {
	var $name = 'Auth';
	var $helpers = array('Html', 'Form' );
	var $uses = array('Blog');
	
	function login() {
		//se já fez o login redireciona
		if($this->Session->check('logado')) {
			$this->redirect('admin/posts/index');
		}
		
		if(empty($this->params['form']['email'])) {//invoca o formulário
			$this->render();
		}
		else {
			//valida
			$email = $this->params["form"]["email"];
			$senha = $this->params["form"]["senha"];
			//busca o usuário pelo e-mail cadastrado
			$blog = $this->Blog->findByEmail($email);
			//verifica se o usuário existe e se a senha está correta
			if(!empty($blog) && $blog["Blog"]["senha"] == $senha) {
				//escreve na sessão
				$this->Session->write('logado',$email);
				$this->redirect('admin/posts/index');
			}
			else {
				$this->Session->setFlash('Usuário ou senha inválidos');
				$this->redirect('auth/login');
			}
		}
	}
	
	function logout() {
		$this->Session->delete('logado');
		$this->redirect('/');
	}
}
?>