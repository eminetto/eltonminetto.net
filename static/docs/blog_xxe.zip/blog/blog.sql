-- phpMyAdmin SQL Dump
-- version 2.10.2
-- http://www.phpmyadmin.net
-- 
-- Máquina: localhost
-- Data de Criação: 22-Set-2007 às 15:32
-- Versão do servidor: 5.0.45
-- versão do PHP: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Base de Dados: `blog`
-- 

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `blogs`
-- 

CREATE TABLE `blogs` (
  `id` int(11) NOT NULL auto_increment,
  `nome` varchar(100) NOT NULL,
  `descricao` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `senha` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Extraindo dados da tabela `blogs`
-- 

INSERT INTO `blogs` (`id`, `nome`, `descricao`, `email`, `senha`) VALUES 
(1, 'Blog do Elton', 'Novo blog do Elton Minetto', 'eminetto@gmail.com', 'teste');

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `comentarios`
-- 

CREATE TABLE `comentarios` (
  `id` int(11) NOT NULL auto_increment,
  `post_id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `texto` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `post_id` (`post_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

-- 
-- Extraindo dados da tabela `comentarios`
-- 

INSERT INTO `comentarios` (`id`, `post_id`, `nome`, `email`, `texto`) VALUES 
(1, 3, 'Elton Minetto', 'eminetto@gmail.com', 'sdofjdiof\r\ndsfodsfiojsdijf\r\n\r\nsfiodsjfiodsi\r\nsdf\r\nsdf\r\ndsfdsdsfdsd\r\n\r\ndsfds'),
(2, 2, 'dfgfd', 'dfgdfg@lsls.com', 'dfgfd'),
(3, 2, 'dfgdf', 'dfgdfg@lsls.com', 'dfdfgfdfgd'),
(4, 3, 'Pedro da Silva', 'dsiofjdsiofjds@lsls.com', '\r\nfdfgfd\r\ndfg\r\nfdgdfgfdgfd'),
(5, 2, 'Elton Minetto', 'eminetto@gmail.com', 'Muito legal este seu texto\r\nlkdfjdskf\r\ndsfdsjfdsj\r\nsdfsdfd'),
(6, 3, 'comentario da apresentaÃ§Ã£o', 'sdfds@lsls.com', 'dsfsdfds'),
(7, 2, 'cvvcbvc', 'slsl@slls.com', 'iiuhuihui'),
(8, 2, 'cvvcbvc', 'slsl@slls.com', 'iiuhuihui');

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `posts`
-- 

CREATE TABLE `posts` (
  `id` int(11) NOT NULL auto_increment,
  `blog_id` int(11) NOT NULL,
  `titulo` varchar(100) NOT NULL,
  `texto` text NOT NULL,
  `data` date NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `blog_id` (`blog_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

-- 
-- Extraindo dados da tabela `posts`
-- 

INSERT INTO `posts` (`id`, `blog_id`, `titulo`, `texto`, `data`) VALUES 
(2, 1, 'Teste', 'Testando o novo blog', '2007-09-18'),
(3, 1, 'Mais um teste', 'djfsdiofs\r\nosdjfiosdjf\r\nsdoijsdfjsdifsd\r\ns\r\ndfsdfsddfs', '2007-09-19'),
(4, 1, 'Teste de Título', 'dfijiodfg\r\niodfjgdfiojgdf\r\ndfigjdfiogjfdoi', '2007-09-21'),
(5, 1, 'sdfdsfds', 'dsfdsfdsfds', '1949-03-02');

-- 
-- Constraints for dumped tables
-- 

-- 
-- Limitadores para a tabela `comentarios`
-- 
ALTER TABLE `comentarios`
  ADD CONSTRAINT `comentarios_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- 
-- Limitadores para a tabela `posts`
-- 
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`blog_id`) REFERENCES `blogs` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
