/* 
Elton Luís Minetto
Implementação da Interface
*/
import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.*;
import java.net.*;

public class MonteCarloImpl extends UnicastRemoteObject implements MonteCarlo {
	public MonteCarloImpl() throws RemoteException{
		super();
	}

	public int pi(long trials) {
		System.out.println("Executando cálculo....");
		int hits = 0;
		double x, y;
		for(int i=0; i < trials; i++) {
          		x = Math.random();
			y = Math.random();
			if(( (x*x) + (y*y)) < 1)
				hits++;
		}
		return hits;
	}
}
