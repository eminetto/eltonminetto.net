/* 
Elton Luís Minetto
Servidor RMI que irá realizar o cálculo
*/
import java.net.*;
import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.*;

public class MonteCarloServer {
	public static void main (String args [ ]) {
		try {
			//Cria MonteCarloImpl
			MonteCarloImpl obj = new MonteCarloImpl();
			Naming.rebind("MonteCarloServer", obj); //registra
			System.out.println("MonteCarlo Server pronto.");
		} catch(Exception e) {
			System.out.println("MonteCarloServer erro"+ e.getMessage());
		}
        }
}
