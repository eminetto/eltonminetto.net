/* 
Elton Luís Minetto
Cliente que conecta aos servidores e finaliza o cálculo do PI
*/
import java.net.*;
import java.rmi.*;
import java.rmi.registry.*;
import java.rmi.server.*;
import java.rmi.Naming;

//thread que irá conectar a um servidor
class ClienteThread extends Thread {
	long trials;
	String server;
	int result;
	public ClienteThread(String server, long trials) {
		super();
		this.trials = trials;
		this.server = server;
	}
	public void run() {
		try {
			System.out.println("Executando thread");
			//usa o objeto distribuído do servidor RMI
			MonteCarlo obj = (MonteCarlo)Naming.lookup(this.server);
			this.result = obj.pi(this.trials);
		} catch(Exception e) {
			this.result = 0;
			System.out.println("erro na thread "+e.getMessage());
		}
	}
	
	public int getResult() {
		return this.result;
	}
}

public class MonteCarloClient {

	public static void main(String args[ ]) {
		try {
			long trials = Long.parseLong( args[0] );//numero de tentativas
			long trials_por_server = 0;
			double result = 0;
			//endereços dos servidores. TODO: ler de um arquivo de configurações
			String servers[] = {"rmi://127.0.0.1/MonteCarloServer","rmi://10.0.0.17/MonteCarloServer","rmi://10.0.0.11/MonteCarloServer","rmi://10.0.0.12/MonteCarloServer","rmi://10.0.0.13/MonteCarloServer","rmi://10.0.0.15/MonteCarloServer"};
			//numero de tentativas por servidor			
			trials_por_server = trials / servers.length;
			//threads que irão conectar aos servidores
			ClienteThread th[] = new ClienteThread[servers.length];
			for(int i = 0; i < servers.length; i++ ) {
				th[i] = new ClienteThread(servers[i],trials_por_server);
				th[i].start();
			}
			//espera o fim da thread para pegar o resultado
			for(int i = 0; i < servers.length; i++ ) {
				th[i].join();
				result += th[i].getResult();
			}
			//resultado final
			result = 4.0*result/trials;
			System.out.println(result);
		} catch(Exception e) {
			System.out.println("MonteCarloClient erro"+ e.getMessage());
		}
		System.exit(0);
	}
}
