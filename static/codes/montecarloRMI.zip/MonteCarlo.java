/* 
Elton Luís Minetto
Interface que define os métodos que estarão disponíveis
*/
import java.net.*;
import java.rmi.*;

public interface MonteCarlo extends Remote {
	int pi(long trials) throws RemoteException;
}
