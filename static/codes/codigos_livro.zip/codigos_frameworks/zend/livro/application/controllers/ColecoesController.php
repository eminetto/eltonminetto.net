<?php
class ColecoesController extends Zend_Controller_Action
{
	public function init() {
		Zend::loadClass('Colecaos');
	}

	public function indexAction() {
		$view = Zend::registry('view');
		$session = Zend::registry('session');
		$id = $session->id;
		
		$colecaos = new Colecaos();
		$db = $colecaos->getAdapter();
		$where = $db->quoteInto("usuario_id = ?",$id);
		$view->colecaos = $colecaos->fetchAll($where);
		
		$view->actionTemplate = 'colecaosIndex.php';
		$this->_response->setBody($view->render('site.php'));
	}
	
	public function addAction() {
		$session = Zend::registry('session');
		$colecaos = new Colecaos();
		$data = array(
			'usuario_id' => $session->id
		);
		$id = $colecaos->insert($data);
		$this->_redirect("/colecoes/edit/?id=$id");
	}
	
	public function editAction() {
		$get = Zend::registry('get');
		$post = Zend::registry('post');

		if(!$post->noTags('id')) {
			$id = (int)$get->noTags('id'); 
			$view = Zend::registry('view');
			//busca e mostra o formulário
			$colecaos = new Colecaos;
			$view->colecaos	= $colecaos->find($id);
			$view->actionTemplate = 'colecaosAdd.php';
			$this->_response->setBody($view->render('site.php'));
		} 
		else {
			$id = (int) $post->noTags('id');
			$colecaos = new Colecaos;
			$colecao = $colecaos->find($id);
			$colecao->nome = $post->noTags('nome');
			$colecao->save();
			$this->_redirect('/colecoes/index');
		}
	}
	
	public function delAction() {
		$get = Zend::registry('get');
		$id = (int)$get->noTags('id'); 
		
		$colecaos = new Colecaos();
		$db = $colecaos->getAdapter();
		$where = $db->quoteInto('id=?', $id);
		$colecaos->delete($where);
		$this->_redirect('/colecoes/index');
		
	}
	
}
?>