<?php
class LivrosController extends Zend_Controller_Action
{
	public function init() {
		Zend::loadClass('Livros');
		Zend::loadClass('Colecaos');
	}

	public function indexAction() {
		$view = Zend::registry('view');
		$session = Zend::registry('session');
		$db = Zend::registry('db');
		$id = $session->id;
		
		$select = $db->select();
		$select->from('livros','livros.nome as livro_nome, livros.id, livros.autor, colecao_id');
		$select->from('colecaos','colecaos.nome as colecao_nome');
		$select->where('usuario_id = ?',$id);
		$select->where('colecaos.id = livros.colecao_id');
		$view->dados = $db->fetchAll($select);
		
		$view->actionTemplate = 'livrosIndex.php';
		$this->_response->setBody($view->render('site.php'));
	}
	
	public function addAction() {
		$session = Zend::registry('session');
		//busca uma coleção para inserir 
		$colecaos = new Colecaos();
		$db = $colecaos->getAdapter();
		$where = $db->quoteInto("usuario_id = ?",$session->id);
		$row = $colecaos->fetchRow($where);
		
		
		$data = array(
			'colecao_id' => $row->id
		);
		$livros = new Livros();
		$id = $livros->insert($data);
		$this->_redirect("/livros/edit/?id=$id");
	}
	
	public function editAction() {
		$get = Zend::registry('get');
		$post = Zend::registry('post');
		$session = Zend::registry('session');

		if(!$post->noTags('id')) {
			$id = (int)$get->noTags('id'); 
			$view = Zend::registry('view');
			//busca e mostra o formulário
			$livros = new Livros;
			$view->livros	= $livros->find($id);
			//busca as coleções do usuário
			$colecaos = new Colecaos;
			$db = $colecaos->getAdapter();
			$where = $db->quoteInto("usuario_id = ?",$session->id);
			$view->colecaos = $colecaos->fetchAll($where);
			
			$view->actionTemplate = 'livrosAdd.php';
			$this->_response->setBody($view->render('site.php'));
		} 
		else {
			$id = (int) $post->noTags('id');
			$livros = new Livros;
			$livro = $livros->find($id);
			$livro->nome = $post->noTags('nome');
			$livro->colecaoId = $post->noTags('colecao_id');
			$livro->autor = $post->noTags('autor');
			$livro->genero = $post->noTags('genero');
			$livro->editora = $post->noTags('editora');
			$livro->anoPublic = $post->noTags('ano_public');
			$livro->save();
			$this->_redirect('/livros/index');
		}
	}
	
	public function delAction() {
		$get = Zend::registry('get');
		$id = (int)$get->noTags('id'); 
		
		$livros = new Livros();
		$db = $livros->getAdapter();
		$where = $db->quoteInto('id=?', $id);
		$livros->delete($where);
		$this->_redirect('/livros/index');
		
	}
	
	public function comentariosAction() {
		Zend::loadClass('Comentarios');
		$get = Zend::registry('get');
		$view = Zend::registry('view');
		
		$id = $get->noTags('id');
		//busca os dados do livro
		$livros = new Livros();
		$view->livro = $livros->find($id);
		//busca os comentarios
		$comentarios = new Comentarios();
		$view->comentarios = $comentarios->fetchAll("livro_id = $id");
		
		$view->actionTemplate = 'livrosComentarios.php';
		$this->_response->setBody($view->render('site.php'));
		
		
	}
	
}
?>