<?php
class ComentariosController extends Zend_Controller_Action 
{
	public function init() {
		Zend::loadClass('Comentarios');
	}
	
	public function addAction() {
		$get = Zend::registry('get');
		$livro_id = (int)$get->noTags('livro_id');
		$data = array(
			'livro_id' => $livro_id
		);
		$comentario = new Comentarios();
		$id = $comentario->insert($data);
		$this->_redirect("/comentarios/edit/?id=$id");
	}
	
	public function editAction() {
		$get = Zend::registry('get');
		$post = Zend::registry('post');
		$session = Zend::registry('session');

		if(!$post->noTags('id')) {
			$id = (int)$get->noTags('id'); 
			$view = Zend::registry('view');
			//busca 
			$comentario = new Comentarios;
			$db = $comentario->getAdapter();
			$where = $db->quoteInto("id = ?",$id);
			$view->comentario = $comentario->fetchAll($get);
			
			$view->actionTemplate = 'comentariosAdd.php';
			$this->_response->setBody($view->render('site.php'));
		} 
		else {
			$id = (int) $post->noTags('id');
			$comentario = new Comentarios;
			$comentario = $comentario->find($id);
			$comentario->nome = $post->noTags('nome');
			$comentario->livroId = $post->noTags('livro_id');
			$comentario->email = $post->noTags('email');
			$comentario->site = $post->noTags('site');
			$comentario->texto = $post->noTags('texto');
			$comentario->save();
			$this->_redirect('/livros/comentarios/?id='.$post->noTags('livro_id'));
		}
	}	
}
?>