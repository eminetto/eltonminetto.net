<?php
class IndexController extends Zend_Controller_Action
{
	public function init() {
		Zend::loadClass('Livros');
		Zend::loadClass('Usuarios');		
		Zend::loadClass('Colecaos');
		Zend::loadClass('Comentarios');
	}
		
	public function indexAction() {
		$view = Zend::registry('view');
		//busca as colecoes
		$colecaos = new Colecaos();
		$c = $colecaos->fetchAll();
		$i = 0;
		foreach($c as $colecao) {
			$view->dados[$i]['Colecaos'] = $colecao;
			//busca o usuario
			$usuarios = new Usuarios();
			$view->dados[$i]['Usuarios'] = $usuarios->find($colecao->usuarioId);
			//busca os livros da colecao
			$livros = new Livros();
			$view->dados[$i]['Livros'] = $livros->fetchAll("colecao_id=$colecao->id");
			$i++;
		}
		//echo $colecaos->getUsuario();exit;
		//busca os livros
		///$select = $db->select();
		///$select->from('livros','livros.id as livro_id, livros.nome as livro_nome');
		///$select->from('usuarios', 'usuarios.nome as usuario_nome');
		///$select->from('colecaos', 'colecaos.id as colecao_id, colecaos.nome as colecao_nome');
		///$select->where('usuarios.id = colecaos.usuario_id');
		///$select->where('colecaos.id = livros.colecao_id');
		//$select->from('colecaos','colecaos.*');
		//$select->from('usuarios','usuarios.*');
		//$select->join('colecaos','livros.colecao_id = colecaos.id','*');
		//$select->join('usuarios','colecaos.usuario_id = usuarios.id','*');
		///$view->colecaos = $db->fetchAll($select);
		$view->actionTemplate = 'indexIndex.php';
		//echo $view->render('indexView.php');
		$this->_response->setBody($view->render('site.php'));
	}
	
	public function loginAction() {
		$view = Zend::registry('view');
		$session = Zend::registry('session');
		//pega os dados do post
		$post = Zend::registry('post');
		$email = trim($post->noTags('email'));
		$senha = trim($post->noTags('senha'));
		$usuario = new Usuarios();		
		$db = $usuario->getAdapter();
		$where = $db->quoteInto("email = ?",$email);
		$row = $usuario->fetchRow($where);
		if(!$row->id) {
			$session->valid = 0;
			$session->hasErro = 1;
			$session->erro = 'Usuário não existe';
			$this->_redirect('/');
		}
		elseif ($row->senha != $senha) {
			$session->valid = 0;
			$session->hasErro = 1;
			$session->erro = 'Senha incorreta';
			$this->_redirect('/');
		}
		else {
			$session->valid = 1;
			$session->hasErro = 0;
			$session->id = $row->id;
			$this->_redirect('/index/menu');
		}
		$this->_response->setBody($view->render('site.php'));
		
		
	}
	
	function logoutAction() {
		$session = Zend::registry('session');
		$session->valid = 0;
		$session->hasErro = 0;
		$session->email = '';
		$this->_redirect('/');
	}
	
	public function menuAction() {
		$view = Zend::registry('view');
		$view->actionTemplate = 'indexMenu.php';
		$this->_response->setBody($view->render('site.php'));	
	}
	
	/*public function addAction() {
		$view = Zend::registry('view');
		echo $view->render('formulario.php');
	}
	
	public function insertAction() {
		if (strtolower($_SERVER['REQUEST_METHOD']) == 'post') {
				$post = Zend::registry('post');
				$nome = trim($post->noTags('nome'));
				$email = trim($post->noTags('email'));
				$senha = trim($post->noTags('senha'));
				$data = array(
					'nome' => $nome,
					'email' => $email,
					'senha' => $senha
				);
				$usuario = new Usuarios();
				$usuario->insert($data);
				$this->_redirect('/');
				return;
		}
	}*/
}
?>