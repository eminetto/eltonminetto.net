<h2>Comentários do livro <?=$this->livro->nome?></h2>
<?php
foreach($this->comentarios as $c) {
	?>
	<b>Comentário:</b><?=$this->escape($c->texto)?><br>
	<b>Autor:</b><?=$this->escape($c->nome)?><br>
	<b>Site:</b><?=$this->escape($c->site)?><br><br>
	<?
}
?>
<li><a href="/zend/meuslivros/comentarios/add/?livro_id=<?=$this->livro->id?>">Adicionar comentário</a></li>
<li><a href="/zend/meuslivros/">Voltar</a></li>