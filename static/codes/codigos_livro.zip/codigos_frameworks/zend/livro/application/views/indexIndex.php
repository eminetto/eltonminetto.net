<h2>Login</h2>
<?php
$session = new Zend_Session();
if($session->hasErro)  {
	?>
	<div id="erro">
		<?=$session->erro?>
	</div>
	<?
}
?>
<form action="/zend/meuslivros/index/login" method="post">
<label>e-mail:</label> <input type="text" name="email"><br>
<label>senha:</label> <input type="password" name="senha"><br>
<input type="submit" value="entrar">
</form>
<h2>Coleções</h2>
<?php
//echo "<xmp>";var_dump($this->colecaos);echo "</xmp>";exit;
foreach($this->dados as $dado) {
	?>
	<h3><?=$dado['Colecaos']->nome?></h3>
	<b>Proprietário:</b><?=$dado['Usuarios']->nome?> <br>
	RSS
	<h4>Livros</h4>
	<?
	//livros
	foreach($dado['Livros'] as $livro) {
		?>
		<b>Título:</b> <?=$livro->nome?><br>
		<b>Capa:</b> <?=$livro->capa?><br>
		<b>Gênero:</b> <?=$livro->genero?><br>
		<b>Autor:</b> <?=$livro->autor?><br>
		<b>Editora:</b> <?=$livro->editora?><br>
		<b>Ano de Publicação:</b> <?=$livro->anoPublic?><br>
		<a href="/zend/meuslivros/livros/comentarios/?id=<?=$livro->id?>">Ver comentários</a>
		<br><br>
		<?
	}
	
}
?>
<br><a href="/zend/index/add">adicionar livro</a>