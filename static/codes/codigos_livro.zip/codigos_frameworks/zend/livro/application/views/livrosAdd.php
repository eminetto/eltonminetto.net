<form name="addLivrosForm" method="post" action="/zend/meuslivros/livros/edit">
<input type="hidden" name="id" value="<?=$this->livros->id?>">
<label>Nome do Livro</label><input type="text" name="nome" value="<?=$this->livros->nome?>"><br>
<label>Coleção</label>
	<select name="colecao_id">
		<?php
		foreach($this->colecaos as $colecao) {
			?>
			<option value="<?=$colecao->id?>"><?=$colecao->nome?></option>
			<?
		}
		?>
	</select><br>
<label>Gênero</label><input type="text" name="genero" value="<?=$this->livros->genero?>"><br>
<label>Autor</label><input type="text" name="autor" value="<?=$this->livros->autor?>"><br>
<label>Editora</label><input type="text" name="editora" value="<?=$this->livros->editora?>"><br>
<label>Ano de publicação</label><input type="text" name="ano_public" value="<?=$this->livros->anoPublic?>"><br>
<input type="submit" value="Salvar">
</form>
<li><a href="/zend/meuslivros/livros/">Voltar</a></li>