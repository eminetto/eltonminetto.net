<form name="addColecaoForm" method="post" action="/zend/meuslivros/colecoes/edit">
<input type="hidden" name="id" value="<?=$this->colecaos->id?>">
<label>Nome da coleção</label><input type="text" name="nome" value="<?=$this->colecaos->nome?>">
<input type="submit" value="Salvar">
</form>
<li><a href="/zend/meuslivros/colecoes/">Voltar</a></li>