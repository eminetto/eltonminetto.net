<h2>Coleções</h2>
<table border="1">
<tr>
	<td>id</td>
	<td>nome</td>
	<td>ações</td>
</tr>
<?php
foreach($this->colecaos as $colecao) {
	?>
	<tr>
		<td><?=$colecao->id?></td>
		<td><?=$colecao->nome?></td>
		<td>
			<a href="/zend/meuslivros/colecoes/edit/?id=<?=$colecao->id?>">Editar</a> ||
			<a href="/zend/meuslivros/colecoes/del/?id=<?=$colecao->id?>">Excluir</a>
		</td>
	</tr>
	<?
}
?>
</table>
<br>
<li><a href="/zend/meuslivros/colecoes/add">Adicionar nova coleção</a></li>
<li><a href="/zend/meuslivros/index/menu">Menu Principal</a></li>