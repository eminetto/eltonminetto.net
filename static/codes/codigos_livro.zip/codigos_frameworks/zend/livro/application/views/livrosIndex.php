<table border="1">
<tr>
	<td>id</td>
	<td>titulo</td>
	<td>autor</td>
	<td>coleçao</td>
	<td>ações</td>
</tr>
<?php
foreach($this->dados as $d) {
	?>
	<tr>
		<td><?=$d['id']?></td>
		<td><?=$d['livro_nome']?></td>
		<td><?=$d['autor']?></td>
		<td><?=$d['colecao_nome']?></td>
		<td>
			<a href="/zend/meuslivros/livros/edit/?id=<?=$d['id']?>">Editar</a> ||
			<a href="/zend/meuslivros/livros/del/?id=<?=$d['id']?>">Excluir</a>
		</td>
	</tr>
	<?
}
?>
</table>
<br>
<li><a href="/zend/meuslivros/livros/add">Adicionar novo livro</a></li>
<li><a href="/zend/meuslivros/index/menu">Menu Principal</a></li>