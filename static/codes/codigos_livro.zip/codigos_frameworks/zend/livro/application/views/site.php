<html>
<head>
<title>Meus Livros</title>
<link rel="stylesheet" type="text/css" media="screen" href="/zend/meuslivros/public/styles/site.css" />

</head>
<body>
<h1>Meus Livros</h1>
<?php echo $this->render($this->actionTemplate); ?>
<?php
$session = new Zend_Session();
if($session->valid) {
	?>
	<li><a href="/zend/meuslivros/index/logout">Sair</a></li>
	<?php
}
?>
</body>
</html>
