<?php
class Livros extends Zend_Db_Table
{
}
?>