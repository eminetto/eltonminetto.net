<?php
class Usuarios extends Zend_Db_Table
{
}
?>