<?php
class Colecaos extends Zend_Db_Table
{

}
?>