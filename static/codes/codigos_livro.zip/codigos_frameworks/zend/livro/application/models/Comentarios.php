<?php
class Comentarios extends Zend_Db_Table
{
}
?>