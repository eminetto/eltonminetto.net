<?php
error_reporting(E_ALL|E_STRICT);
date_default_timezone_set('Europe/London');
set_include_path('.' . PATH_SEPARATOR . '../library'. PATH_SEPARATOR . './application/models/'. PATH_SEPARATOR . get_include_path());
include "Zend.php";
include "Zend/Session.php";
Zend::loadClass('Zend_Controller_Front');
Zend::loadClass('Zend_View');
Zend::loadClass('Zend_Config_Ini'); //ler configurações
Zend::loadClass('Zend_Db'); //database
Zend::loadClass('Zend_Db_Table'); //database
Zend::loadClass('Zend_Filter_Input'); //usar o post
// register the input filters
Zend::register('post', new Zend_Filter_Input($_POST, false));
Zend::register('get', new Zend_Filter_Input($_GET, false));

//view
$view = new Zend_View;
$view->addScriptPath('./application/views');
Zend::register('view', $view);

//sessao
$session = new Zend_Session();
Zend::register('session', $session);

// setup controller
$baseUrl = substr($_SERVER['PHP_SELF'], 0, strpos($_SERVER['PHP_SELF'], '/index.php'));
$frontController = Zend_Controller_Front::getInstance();
$frontController->setBaseUrl($baseUrl);
$frontController->setControllerDirectory('./application/controllers');
$frontController->throwExceptions(true);

//configurações da base de dados
$config = new Zend_Config_Ini('./application/config.ini', 'database'); //arquivo,seção do .ini
Zend::register('config', $config);

// setup database
$db = Zend_Db::factory($config->db->adapter, $config->db->config->asArray());
Zend_Db_Table::setDefaultAdapter($db);
Zend::register('db',$db);
//para funcionar a base de dados foi preciso instalar o pdo pq o ZendF só funciona com pdo:
// pecl install pdo
//apt-get install libmysqlclient12-dev
// pecl install pdo_mysql
//php.ini: extension=pdo.so e extension=pdo_mysql.so

// run!
$frontController->dispatch();
?>