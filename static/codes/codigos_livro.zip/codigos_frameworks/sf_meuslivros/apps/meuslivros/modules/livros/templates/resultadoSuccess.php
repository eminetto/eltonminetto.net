<h2>Livros Encontrados</h2>
<?
foreach($livros as $livro) {
    echo $livro->getNome().'<br>';
}
?>
