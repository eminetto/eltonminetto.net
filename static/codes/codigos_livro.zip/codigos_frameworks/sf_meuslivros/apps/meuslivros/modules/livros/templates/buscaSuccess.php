<?//indica que irá usar o helper de javascript para o Ajax
echo use_helper('Javascript') ;
?>
<?//cria um formulário cuja ação será executada usando Ajax
echo form_remote_tag(array(
   'update' => 'resultado',
   'url'  => 'livros/resultado',
)); ?>
 <label for="titulo">Título:</label>
 <?php echo input_tag('nome') ?>
 <?php echo submit_tag('Buscar') ?>
</form>
<!-- div onde será mostrado o resultado-->
<div id='resultado'></div>
