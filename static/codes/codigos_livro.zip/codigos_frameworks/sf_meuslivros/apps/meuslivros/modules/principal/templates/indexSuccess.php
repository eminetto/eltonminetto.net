<?php
//se foi encontrado algum erro no login este é mostrado
if ($sf_request->hasErrors()) {
	echo $sf_request->getError('name'); 
}
?>

<!-- formulário de login-->
<?php //echo form_tag('principal/login') 
?>
<?php //echo form_tag('principal/login', 'method=get multipart=true class=simpleForm') ?>
e-mail: <input type="text" name="email">
senha: <input type="password" name="senha">
<input type="submit" value="entrar">
</form>
<br>
<!-- link para cadastrar um novo usuário-->
<li><?php echo link_to('Cadastrar','usuarios/create')?></li>

<h2>Coleções</h2>
<?php
//para cada elemento do array de coleções
foreach($colecaos as $c) {
        //mostra os dados. devem ser sempre acessados da forma $c->getNome(), por exemplo.
	?>
	<h3><?=$c->getNome()?></h3>
        <!-- o método $c->getUsuarios() retorna um objeto Usuario, que possui um nome-->
	<b>Proprietário:</b> <?=$c->getUsuarios()->getNome()?><br>
	<a href="feed://localhost/sf_meuslivros/web/meuslivros_dev.php/principal/rss/id/<?=$c->getId()?>">RSS</a><br>
	<h4>Livros</h4>
	<?
        //o método getLivross() retorna um array de livros que fazem parte da colecão
	foreach($c->getLivross() as $livro) {
		?>
		<b>Título:</b> <?=$livro->getNome()?><br>
		<b>Capa:</b> <?=$livro->getCapa()?><br>
		<b>Gênero:</b> <?=$livro->getGenero()?><br>
		<b>Autor:</b> <?=$livro->getAutor()?><br>
		<b>Editora:</b> <?=$livro->getEditora()?><br>
		<b>Ano de Publicação:</b> <?=$livro->getAnoPublic()?><br>
		<a href="livros/show/id/<?=$livro->getId()?>" target="verCom">Ver comentários</a><br>
		<br><br>
		<?
	}
}
?>
