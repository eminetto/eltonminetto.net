<h2>Menu</h2>

<li><?php echo link_to('Gerenciar Coleções','colecaos/create')?></li>
<li><?php echo link_to('Gerenciar Livros','livros/create')?></li>
