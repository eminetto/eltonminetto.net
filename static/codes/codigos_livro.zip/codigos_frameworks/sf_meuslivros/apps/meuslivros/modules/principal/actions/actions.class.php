<?php

/**
 * principal actions.
 *
 * @package    sf_sandbox
 * @subpackage principal
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 2692 2006-11-15 21:03:55Z fabien $
 */
class principalActions extends sfActions
{
  /**
   * Executa a ação index
   *
   */
  public function executeIndex()
  {
    $this->colecaos = ColecaosPeer::doSelect(new Criteria());
  }

  /**
   * Executa a ação login
   *
   */
  public function executeLogin()  {
    //busca os parâmetros digitados no formulário pelo usuário
    $email = $this->getRequestParameter('email');
    $senha = $this->getRequestParameter('senha');
    
    //cria um novo critério para ser utilizado na consulta
    $c = new Criteria();
    //neste critério adiciona a condição email = $email.
    $c->add(UsuariosPeer::EMAIL, $email);
    //executa a consulta SQL
    $usuario = UsuariosPeer::doSelectOne($c);
 
    // existe usuario e a senha digitada é igual a senha na base de dados
    if ($usuario && $usuario->getSenha() == $senha)
    {
        $this->getUser()->setAuthenticated(true);//usuario autenticado. é colocado na sessão
		$this->getUser()->addCredential('normal');  //credencial do usuario. será usado posteriormente
        $this->getUser()->setAttribute('id', $usuario->getId(), 'normal'); //adiciona o id na sessão, na credencial
        $this->getUser()->setAttribute('email', $usuario->getEmail(), 'normal');//adiciona o email na sessão, na credencial
        // redireciona para o menu
        return $this->redirect('principal/menu/');
    }
    else { 
      //adiciona uma mensagem de erro na requisição enviada pelo usuario
      $this->getRequest()->setError('name', 'Usuário ou senha não existentes');	
      //redireciona para o index com a mensagem de erro para o usuário digitar novamente
      $this->forward('principal', 'index');	
    }	
  }
  
  /**
   * Executa a ação de mostrar o menu
   *
   */
  public function executeMenu() {
    //não é necessário ter nenhum comando pois irá mostrar o menuSuccess.php
  }

  /**
   * Executa a ação de logout
   *
   */
  public function executeLogout() {
    $this->getUser()->setAuthenticated(false); //remove da sessão 
    $this->getUser()->clearCredentials(); //remove as credenciais do usuário
    //redireciona para a homepage, ou seja principal/index
    $this->redirect('@homepage'); 
  }

  /**
   * Cria o RSS
   *
   */
  public function executeRss() {
    //pega o id da coleção
    $id = $this->getRequestParameter('id');
    //cria um novo critério
    $c = new Criteria();
    //busca pelo id
    $c->add(ColecaosPeer::ID, $id);
    //busca os detalhes da colecao
    $colecao = ColecaosPeer::doSelect($c);

    //busca os livros da coleçao
    $c = new Criteria();
    //busca pelo id da colecao
    $c->add(LivrosPeer::COLECAO_ID, $id);
    //executa a consulta
    $livros = LivrosPeer::doSelect($c);
    
    //cria uma nova instancia do plugin de geração de RSS
    $feed = sfFeed::newInstance('rss201rev2');
 
    // detalhes do canal RSS
    $feed->setTitle('Coleção '.$colecao[0]->getNome());
    $feed->setLink('@homepage');
    $feed->setDescription('Lista de livros desta coleção');
  
    // itens
    $feed->setFeedItemsRouteName('@homepage'); //quando clicar em um ítem vai direcionar para pagina inicial
    $feed->setItems($livros);
  
    $this->feed = $feed;  
  }

}
