<!-- se existem erros -->
<?php if ($sf_request->hasErrors()): ?>
  <h2>Existem dados incorretos:</h2>
  <ul>
  <!-- para cada erro é mostra do a mensagem-->
  <?php foreach($sf_request->getErrors() as $name => $error): ?>
    <li><?php echo $name ?>: <?php echo $error ?></li>
  <?php endforeach; ?>
  </ul>
<?php endif; ?>
<!-- link para voltar ao formulário-->
<?php echo link_to('Voltar', 'usuarios/edit?id='.$sf_params->get('id')) ?>