<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<style>
/* CSS adicionado */
body{
font-family:"frutiger linotype","lucida grande",helvetica,arial,sans-serif;
color:#333;
font-size: 76%;
}

a{
color:#003d4c;
text-decoration:underline;
}
a:hover{
color:#003d4c;
text-decoration:none;
}

h1, h2, h3, h4{
font-weight:normal;
}

h1{
color: #003d4c;
margin:0.3em 0;
font-size: 180%;
}

h2{
color:#c6c65b;
padding-top: 1em;
margin:0.3em 0;
font-size: 180%;
}

h3{
color:#c6c65b;
padding-top:2em;
font-size: 140%;
}

ul, li {
margin: 0 12px;
}

</style>
<head>
<!-- gera os meta-tags do HTML-->
<?php include_http_metas() ?>
<?php include_metas() ?>

<!-- inclui o título da aplicação-->
<?php include_title() ?>

<link rel="shortcut icon" href="/favicon.ico" />

</head>
<body>
<!-- aqui é onde os dados da aplicação são mostrados. esta linha é obrigatória-->
<?php echo $sf_data->getRaw('sf_content') ?>

<!-- verifica se o usuário foi autenticado. caso esteja adiciona um link para realizar o logout-->
<?php if ($sf_user->isAuthenticated()) { ?>
  <li><?php echo link_to('Sair do sistema', 'principal/logout') ?></li>
<?php } ?>


</body>
</html>
