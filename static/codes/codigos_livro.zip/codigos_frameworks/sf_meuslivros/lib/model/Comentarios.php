<?php

/**
 * Subclass for representing a row from the 'comentarios' table.
 *
 * 
 *
 * @package lib.model
 */ 
class Comentarios extends BaseComentarios
{
}
