<?php

/**
 * Subclass for performing query and update operations on the 'colecaos' table.
 *
 * 
 *
 * @package lib.model
 */ 
class ColecaosPeer extends BaseColecaosPeer
{
}
