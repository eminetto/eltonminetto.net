<?php

/**
 * Subclass for representing a row from the 'colecaos' table.
 *
 * 
 *
 * @package lib.model
 */ 
class Colecaos extends BaseColecaos
{
}
