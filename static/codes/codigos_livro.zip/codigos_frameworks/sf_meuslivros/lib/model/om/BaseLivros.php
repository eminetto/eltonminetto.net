<?php


abstract class BaseLivros extends BaseObject  implements Persistent {


	
	const DATABASE_NAME = 'propel';

	
	protected static $peer;


	
	protected $id;


	
	protected $colecao_id = 0;


	
	protected $nome = 'null';


	
	protected $capa;


	
	protected $genero;


	
	protected $autor = 'null';


	
	protected $editora;


	
	protected $ano_public;


	
	protected $created_at;


	
	protected $updated_at;

	
	protected $aColecaos;

	
	protected $collComentarioss;

	
	protected $lastComentariosCriteria = null;

	
	protected $alreadyInSave = false;

	
	protected $alreadyInValidation = false;

	
	public function getId()
	{

		return $this->id;
	}

	
	public function getColecaoId()
	{

		return $this->colecao_id;
	}

	
	public function getNome()
	{

		return $this->nome;
	}

	
	public function getCapa()
	{

		return $this->capa;
	}

	
	public function getGenero()
	{

		return $this->genero;
	}

	
	public function getAutor()
	{

		return $this->autor;
	}

	
	public function getEditora()
	{

		return $this->editora;
	}

	
	public function getAnoPublic($format = 'Y-m-d')
	{

		if ($this->ano_public === null || $this->ano_public === '') {
			return null;
		} elseif (!is_int($this->ano_public)) {
						$ts = strtotime($this->ano_public);
			if ($ts === -1 || $ts === false) { 				throw new PropelException("Unable to parse value of [ano_public] as date/time value: " . var_export($this->ano_public, true));
			}
		} else {
			$ts = $this->ano_public;
		}
		if ($format === null) {
			return $ts;
		} elseif (strpos($format, '%') !== false) {
			return strftime($format, $ts);
		} else {
			return date($format, $ts);
		}
	}

	
	public function getCreatedAt($format = 'Y-m-d H:i:s')
	{

		if ($this->created_at === null || $this->created_at === '') {
			return null;
		} elseif (!is_int($this->created_at)) {
						$ts = strtotime($this->created_at);
			if ($ts === -1 || $ts === false) { 				throw new PropelException("Unable to parse value of [created_at] as date/time value: " . var_export($this->created_at, true));
			}
		} else {
			$ts = $this->created_at;
		}
		if ($format === null) {
			return $ts;
		} elseif (strpos($format, '%') !== false) {
			return strftime($format, $ts);
		} else {
			return date($format, $ts);
		}
	}

	
	public function getUpdatedAt($format = 'Y-m-d H:i:s')
	{

		if ($this->updated_at === null || $this->updated_at === '') {
			return null;
		} elseif (!is_int($this->updated_at)) {
						$ts = strtotime($this->updated_at);
			if ($ts === -1 || $ts === false) { 				throw new PropelException("Unable to parse value of [updated_at] as date/time value: " . var_export($this->updated_at, true));
			}
		} else {
			$ts = $this->updated_at;
		}
		if ($format === null) {
			return $ts;
		} elseif (strpos($format, '%') !== false) {
			return strftime($format, $ts);
		} else {
			return date($format, $ts);
		}
	}

	
	public function setId($v)
	{

		if ($this->id !== $v) {
			$this->id = $v;
			$this->modifiedColumns[] = LivrosPeer::ID;
		}

	} 
	
	public function setColecaoId($v)
	{

		if ($this->colecao_id !== $v || $v === 0) {
			$this->colecao_id = $v;
			$this->modifiedColumns[] = LivrosPeer::COLECAO_ID;
		}

		if ($this->aColecaos !== null && $this->aColecaos->getId() !== $v) {
			$this->aColecaos = null;
		}

	} 
	
	public function setNome($v)
	{

		if ($this->nome !== $v || $v === 'null') {
			$this->nome = $v;
			$this->modifiedColumns[] = LivrosPeer::NOME;
		}

	} 
	
	public function setCapa($v)
	{

		if ($this->capa !== $v) {
			$this->capa = $v;
			$this->modifiedColumns[] = LivrosPeer::CAPA;
		}

	} 
	
	public function setGenero($v)
	{

		if ($this->genero !== $v) {
			$this->genero = $v;
			$this->modifiedColumns[] = LivrosPeer::GENERO;
		}

	} 
	
	public function setAutor($v)
	{

		if ($this->autor !== $v || $v === 'null') {
			$this->autor = $v;
			$this->modifiedColumns[] = LivrosPeer::AUTOR;
		}

	} 
	
	public function setEditora($v)
	{

		if ($this->editora !== $v) {
			$this->editora = $v;
			$this->modifiedColumns[] = LivrosPeer::EDITORA;
		}

	} 
	
	public function setAnoPublic($v)
	{

		if ($v !== null && !is_int($v)) {
			$ts = strtotime($v);
			if ($ts === -1 || $ts === false) { 				throw new PropelException("Unable to parse date/time value for [ano_public] from input: " . var_export($v, true));
			}
		} else {
			$ts = $v;
		}
		if ($this->ano_public !== $ts) {
			$this->ano_public = $ts;
			$this->modifiedColumns[] = LivrosPeer::ANO_PUBLIC;
		}

	} 
	
	public function setCreatedAt($v)
	{

		if ($v !== null && !is_int($v)) {
			$ts = strtotime($v);
			if ($ts === -1 || $ts === false) { 				throw new PropelException("Unable to parse date/time value for [created_at] from input: " . var_export($v, true));
			}
		} else {
			$ts = $v;
		}
		if ($this->created_at !== $ts) {
			$this->created_at = $ts;
			$this->modifiedColumns[] = LivrosPeer::CREATED_AT;
		}

	} 
	
	public function setUpdatedAt($v)
	{

		if ($v !== null && !is_int($v)) {
			$ts = strtotime($v);
			if ($ts === -1 || $ts === false) { 				throw new PropelException("Unable to parse date/time value for [updated_at] from input: " . var_export($v, true));
			}
		} else {
			$ts = $v;
		}
		if ($this->updated_at !== $ts) {
			$this->updated_at = $ts;
			$this->modifiedColumns[] = LivrosPeer::UPDATED_AT;
		}

	} 
	
	public function hydrate(ResultSet $rs, $startcol = 1)
	{
		try {

			$this->id = $rs->getInt($startcol + 0);

			$this->colecao_id = $rs->getInt($startcol + 1);

			$this->nome = $rs->getString($startcol + 2);

			$this->capa = $rs->getString($startcol + 3);

			$this->genero = $rs->getString($startcol + 4);

			$this->autor = $rs->getString($startcol + 5);

			$this->editora = $rs->getString($startcol + 6);

			$this->ano_public = $rs->getDate($startcol + 7, null);

			$this->created_at = $rs->getTimestamp($startcol + 8, null);

			$this->updated_at = $rs->getTimestamp($startcol + 9, null);

			$this->resetModified();

			$this->setNew(false);

						return $startcol + 10; 
		} catch (Exception $e) {
			throw new PropelException("Error populating Livros object", $e);
		}
	}

	
	public function delete($con = null)
	{
		if ($this->isDeleted()) {
			throw new PropelException("This object has already been deleted.");
		}

		if ($con === null) {
			$con = Propel::getConnection(LivrosPeer::DATABASE_NAME);
		}

		try {
			$con->begin();
			LivrosPeer::doDelete($this, $con);
			$this->setDeleted(true);
			$con->commit();
		} catch (PropelException $e) {
			$con->rollback();
			throw $e;
		}
	}

	
	public function save($con = null)
	{
    if ($this->isNew() && !$this->isColumnModified(LivrosPeer::CREATED_AT))
    {
      $this->setCreatedAt(time());
    }

    if ($this->isModified() && !$this->isColumnModified(LivrosPeer::UPDATED_AT))
    {
      $this->setUpdatedAt(time());
    }

		if ($this->isDeleted()) {
			throw new PropelException("You cannot save an object that has been deleted.");
		}

		if ($con === null) {
			$con = Propel::getConnection(LivrosPeer::DATABASE_NAME);
		}

		try {
			$con->begin();
			$affectedRows = $this->doSave($con);
			$con->commit();
			return $affectedRows;
		} catch (PropelException $e) {
			$con->rollback();
			throw $e;
		}
	}

	
	protected function doSave($con)
	{
		$affectedRows = 0; 		if (!$this->alreadyInSave) {
			$this->alreadyInSave = true;


												
			if ($this->aColecaos !== null) {
				if ($this->aColecaos->isModified()) {
					$affectedRows += $this->aColecaos->save($con);
				}
				$this->setColecaos($this->aColecaos);
			}


						if ($this->isModified()) {
				if ($this->isNew()) {
					$pk = LivrosPeer::doInsert($this, $con);
					$affectedRows += 1; 										 										 
					$this->setId($pk);  
					$this->setNew(false);
				} else {
					$affectedRows += LivrosPeer::doUpdate($this, $con);
				}
				$this->resetModified(); 			}

			if ($this->collComentarioss !== null) {
				foreach($this->collComentarioss as $referrerFK) {
					if (!$referrerFK->isDeleted()) {
						$affectedRows += $referrerFK->save($con);
					}
				}
			}

			$this->alreadyInSave = false;
		}
		return $affectedRows;
	} 
	
	protected $validationFailures = array();

	
	public function getValidationFailures()
	{
		return $this->validationFailures;
	}

	
	public function validate($columns = null)
	{
		$res = $this->doValidate($columns);
		if ($res === true) {
			$this->validationFailures = array();
			return true;
		} else {
			$this->validationFailures = $res;
			return false;
		}
	}

	
	protected function doValidate($columns = null)
	{
		if (!$this->alreadyInValidation) {
			$this->alreadyInValidation = true;
			$retval = null;

			$failureMap = array();


												
			if ($this->aColecaos !== null) {
				if (!$this->aColecaos->validate($columns)) {
					$failureMap = array_merge($failureMap, $this->aColecaos->getValidationFailures());
				}
			}


			if (($retval = LivrosPeer::doValidate($this, $columns)) !== true) {
				$failureMap = array_merge($failureMap, $retval);
			}


				if ($this->collComentarioss !== null) {
					foreach($this->collComentarioss as $referrerFK) {
						if (!$referrerFK->validate($columns)) {
							$failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
						}
					}
				}


			$this->alreadyInValidation = false;
		}

		return (!empty($failureMap) ? $failureMap : true);
	}

	
	public function getByName($name, $type = BasePeer::TYPE_PHPNAME)
	{
		$pos = LivrosPeer::translateFieldName($name, $type, BasePeer::TYPE_NUM);
		return $this->getByPosition($pos);
	}

	
	public function getByPosition($pos)
	{
		switch($pos) {
			case 0:
				return $this->getId();
				break;
			case 1:
				return $this->getColecaoId();
				break;
			case 2:
				return $this->getNome();
				break;
			case 3:
				return $this->getCapa();
				break;
			case 4:
				return $this->getGenero();
				break;
			case 5:
				return $this->getAutor();
				break;
			case 6:
				return $this->getEditora();
				break;
			case 7:
				return $this->getAnoPublic();
				break;
			case 8:
				return $this->getCreatedAt();
				break;
			case 9:
				return $this->getUpdatedAt();
				break;
			default:
				return null;
				break;
		} 	}

	
	public function toArray($keyType = BasePeer::TYPE_PHPNAME)
	{
		$keys = LivrosPeer::getFieldNames($keyType);
		$result = array(
			$keys[0] => $this->getId(),
			$keys[1] => $this->getColecaoId(),
			$keys[2] => $this->getNome(),
			$keys[3] => $this->getCapa(),
			$keys[4] => $this->getGenero(),
			$keys[5] => $this->getAutor(),
			$keys[6] => $this->getEditora(),
			$keys[7] => $this->getAnoPublic(),
			$keys[8] => $this->getCreatedAt(),
			$keys[9] => $this->getUpdatedAt(),
		);
		return $result;
	}

	
	public function setByName($name, $value, $type = BasePeer::TYPE_PHPNAME)
	{
		$pos = LivrosPeer::translateFieldName($name, $type, BasePeer::TYPE_NUM);
		return $this->setByPosition($pos, $value);
	}

	
	public function setByPosition($pos, $value)
	{
		switch($pos) {
			case 0:
				$this->setId($value);
				break;
			case 1:
				$this->setColecaoId($value);
				break;
			case 2:
				$this->setNome($value);
				break;
			case 3:
				$this->setCapa($value);
				break;
			case 4:
				$this->setGenero($value);
				break;
			case 5:
				$this->setAutor($value);
				break;
			case 6:
				$this->setEditora($value);
				break;
			case 7:
				$this->setAnoPublic($value);
				break;
			case 8:
				$this->setCreatedAt($value);
				break;
			case 9:
				$this->setUpdatedAt($value);
				break;
		} 	}

	
	public function fromArray($arr, $keyType = BasePeer::TYPE_PHPNAME)
	{
		$keys = LivrosPeer::getFieldNames($keyType);

		if (array_key_exists($keys[0], $arr)) $this->setId($arr[$keys[0]]);
		if (array_key_exists($keys[1], $arr)) $this->setColecaoId($arr[$keys[1]]);
		if (array_key_exists($keys[2], $arr)) $this->setNome($arr[$keys[2]]);
		if (array_key_exists($keys[3], $arr)) $this->setCapa($arr[$keys[3]]);
		if (array_key_exists($keys[4], $arr)) $this->setGenero($arr[$keys[4]]);
		if (array_key_exists($keys[5], $arr)) $this->setAutor($arr[$keys[5]]);
		if (array_key_exists($keys[6], $arr)) $this->setEditora($arr[$keys[6]]);
		if (array_key_exists($keys[7], $arr)) $this->setAnoPublic($arr[$keys[7]]);
		if (array_key_exists($keys[8], $arr)) $this->setCreatedAt($arr[$keys[8]]);
		if (array_key_exists($keys[9], $arr)) $this->setUpdatedAt($arr[$keys[9]]);
	}

	
	public function buildCriteria()
	{
		$criteria = new Criteria(LivrosPeer::DATABASE_NAME);

		if ($this->isColumnModified(LivrosPeer::ID)) $criteria->add(LivrosPeer::ID, $this->id);
		if ($this->isColumnModified(LivrosPeer::COLECAO_ID)) $criteria->add(LivrosPeer::COLECAO_ID, $this->colecao_id);
		if ($this->isColumnModified(LivrosPeer::NOME)) $criteria->add(LivrosPeer::NOME, $this->nome);
		if ($this->isColumnModified(LivrosPeer::CAPA)) $criteria->add(LivrosPeer::CAPA, $this->capa);
		if ($this->isColumnModified(LivrosPeer::GENERO)) $criteria->add(LivrosPeer::GENERO, $this->genero);
		if ($this->isColumnModified(LivrosPeer::AUTOR)) $criteria->add(LivrosPeer::AUTOR, $this->autor);
		if ($this->isColumnModified(LivrosPeer::EDITORA)) $criteria->add(LivrosPeer::EDITORA, $this->editora);
		if ($this->isColumnModified(LivrosPeer::ANO_PUBLIC)) $criteria->add(LivrosPeer::ANO_PUBLIC, $this->ano_public);
		if ($this->isColumnModified(LivrosPeer::CREATED_AT)) $criteria->add(LivrosPeer::CREATED_AT, $this->created_at);
		if ($this->isColumnModified(LivrosPeer::UPDATED_AT)) $criteria->add(LivrosPeer::UPDATED_AT, $this->updated_at);

		return $criteria;
	}

	
	public function buildPkeyCriteria()
	{
		$criteria = new Criteria(LivrosPeer::DATABASE_NAME);

		$criteria->add(LivrosPeer::ID, $this->id);

		return $criteria;
	}

	
	public function getPrimaryKey()
	{
		return $this->getId();
	}

	
	public function setPrimaryKey($key)
	{
		$this->setId($key);
	}

	
	public function copyInto($copyObj, $deepCopy = false)
	{

		$copyObj->setColecaoId($this->colecao_id);

		$copyObj->setNome($this->nome);

		$copyObj->setCapa($this->capa);

		$copyObj->setGenero($this->genero);

		$copyObj->setAutor($this->autor);

		$copyObj->setEditora($this->editora);

		$copyObj->setAnoPublic($this->ano_public);

		$copyObj->setCreatedAt($this->created_at);

		$copyObj->setUpdatedAt($this->updated_at);


		if ($deepCopy) {
									$copyObj->setNew(false);

			foreach($this->getComentarioss() as $relObj) {
				$copyObj->addComentarios($relObj->copy($deepCopy));
			}

		} 

		$copyObj->setNew(true);

		$copyObj->setId(NULL); 
	}

	
	public function copy($deepCopy = false)
	{
				$clazz = get_class($this);
		$copyObj = new $clazz();
		$this->copyInto($copyObj, $deepCopy);
		return $copyObj;
	}

	
	public function getPeer()
	{
		if (self::$peer === null) {
			self::$peer = new LivrosPeer();
		}
		return self::$peer;
	}

	
	public function setColecaos($v)
	{


		if ($v === null) {
			$this->setColecaoId('null');
		} else {
			$this->setColecaoId($v->getId());
		}


		$this->aColecaos = $v;
	}


	
	public function getColecaos($con = null)
	{
				include_once 'lib/model/om/BaseColecaosPeer.php';

		if ($this->aColecaos === null && ($this->colecao_id !== null)) {

			$this->aColecaos = ColecaosPeer::retrieveByPK($this->colecao_id, $con);

			
		}
		return $this->aColecaos;
	}

	
	public function initComentarioss()
	{
		if ($this->collComentarioss === null) {
			$this->collComentarioss = array();
		}
	}

	
	public function getComentarioss($criteria = null, $con = null)
	{
				include_once 'lib/model/om/BaseComentariosPeer.php';
		if ($criteria === null) {
			$criteria = new Criteria();
		}
		elseif ($criteria instanceof Criteria)
		{
			$criteria = clone $criteria;
		}

		if ($this->collComentarioss === null) {
			if ($this->isNew()) {
			   $this->collComentarioss = array();
			} else {

				$criteria->add(ComentariosPeer::LIVRO_ID, $this->getId());

				ComentariosPeer::addSelectColumns($criteria);
				$this->collComentarioss = ComentariosPeer::doSelect($criteria, $con);
			}
		} else {
						if (!$this->isNew()) {
												

				$criteria->add(ComentariosPeer::LIVRO_ID, $this->getId());

				ComentariosPeer::addSelectColumns($criteria);
				if (!isset($this->lastComentariosCriteria) || !$this->lastComentariosCriteria->equals($criteria)) {
					$this->collComentarioss = ComentariosPeer::doSelect($criteria, $con);
				}
			}
		}
		$this->lastComentariosCriteria = $criteria;
		return $this->collComentarioss;
	}

	
	public function countComentarioss($criteria = null, $distinct = false, $con = null)
	{
				include_once 'lib/model/om/BaseComentariosPeer.php';
		if ($criteria === null) {
			$criteria = new Criteria();
		}
		elseif ($criteria instanceof Criteria)
		{
			$criteria = clone $criteria;
		}

		$criteria->add(ComentariosPeer::LIVRO_ID, $this->getId());

		return ComentariosPeer::doCount($criteria, $distinct, $con);
	}

	
	public function addComentarios(Comentarios $l)
	{
		$this->collComentarioss[] = $l;
		$l->setLivros($this);
	}
        public function __toString() {
          return $this->getNome();
        }

} 