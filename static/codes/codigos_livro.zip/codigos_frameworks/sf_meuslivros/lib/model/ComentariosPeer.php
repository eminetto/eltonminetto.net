<?php

/**
 * Subclass for performing query and update operations on the 'comentarios' table.
 *
 * 
 *
 * @package lib.model
 */ 
class ComentariosPeer extends BaseComentariosPeer
{
}
