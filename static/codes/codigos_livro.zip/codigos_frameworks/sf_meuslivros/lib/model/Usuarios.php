<?php

/**
 * Subclass for representing a row from the 'usuarios' table.
 *
 * 
 *
 * @package lib.model
 */ 
class Usuarios extends BaseUsuarios
{
}
