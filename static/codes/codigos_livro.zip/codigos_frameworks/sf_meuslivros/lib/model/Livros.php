<?php

/**
 * Subclass for representing a row from the 'livros' table.
 *
 * 
 *
 * @package lib.model
 */ 
class Livros extends BaseLivros
{
}
