<?php

/**
 * Subclass for performing query and update operations on the 'livros' table.
 *
 * 
 *
 * @package lib.model
 */ 
class LivrosPeer extends BaseLivrosPeer
{
}
