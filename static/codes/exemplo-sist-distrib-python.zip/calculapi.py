import random
# -*- coding: ISO-8859-1 -*-

# calculapi.py
# author: Mario Olimpio de Menezes
# date: 11/14/2006
# created to teach distributed computing with Python
# using Pyro - Python Remote Objects
# description and comments in Portuguese

# This code is based on Prof. Elton Minetto article
# "M�todo de Monte Carlo Distribu�do" found on
# http://www.eltonminetto.net/metodo-de-monte-carlo-distribuido.htm
# description and comments in portuguese

class calc_pi:
    """esta classe faz o calculo dos hits, isto e,
       do numero de vezes que (x*x) + (y*y) < 1.
       ela tem um metodo (opcional) para inicializar a semente do gerador
       o segundo metodo eh o que de fato calcula o numero de hits
       ele recebe o numero de tentativas (rodadas) e 
       retorna o numero de hits.
    """
    def semente(self,seed_p=None):
        random.seed(seed_p)

    def trials(self, tentativas):
        hitsl = 0
        for i in xrange(tentativas):
           x = random.random()
           y = random.random()
           if (((x*x) + (y*y)) < 1):
                hitsl += 1
        return hitsl
