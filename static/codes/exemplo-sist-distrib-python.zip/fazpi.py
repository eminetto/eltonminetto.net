#!/usr/bin/env python
# -*- coding: ISO-8859-1 -*-

# fazpi.py 
# author: Mario Olimpio de Menezes 
# date: 11/14/2006
# monoprocessed version.
# this code is based on Prof. Elton Minetto example
# found on 
# http://www.eltonminetto.net/metodo-de-monte-carlo-distribuido.htm
# created to teach distributed computing with Python
# using Pyro - Python Remote Objects
# description and comments in Portuguese

import time, sys
import calculapi


def fazpi(tenta):
   x = calculapi.calc_pi()
   pi = 4.0 * x.trials(tenta) / tenta
   return pi

   
def main(args):
    try:
       tenta = int(args[1])
    except:
       tenta = 1000000
    t0 = time.time()
    pi = fazpi(tenta)
    tf = time.time()
    print 'calculando pi com ' , tenta, ' tentativas\n' 
    print "tempo gasto: ", tf-t0, "seg\n\n"
    print  "Valor calculado: %2.10f \n" %(pi)
   

if __name__ == '__main__':
     main(sys.argv)
