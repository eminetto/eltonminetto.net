#!/usr/bin/env python
# -*- coding: ISO-8859-1 -*-

# servidorpi.py 
# author: Mario Olimpio de Menezes 
# date: 11/14/2006
# created to teach distributed computing with Python
# using Pyro - Python Remote Objects
# description and comments in Portuguese


import Pyro.core
import Pyro.naming
from Pyro.protocol import getHostname
from Pyro.errors import PyroError,NamingError

import calculapi
import sys

group = ':pidist'   # namespace para o calculo de PI

class CalculatorProxy(Pyro.core.ObjBase, calculapi.calc_pi):
    def __init__(self):
        Pyro.core.ObjBase.__init__(self)
    
try:
   hostname = sys.argv[1]
except IndexError:
   print 'informe o nome da maquina como argumento de linha de comando.'
   print 'ele sera utilizado para registrar o calculador de pi no NS'
   
Pyro.core.initServer()
Pyro.config.PYRO_NS_DEFAULTGROUP=group
ns = Pyro.naming.NameServerLocator().getNS()
daemon = Pyro.core.Daemon()
# make sure our namespace group exists
try:
	ns.createGroup(group)
except NamingError:
	pass

daemon.useNameServer(ns)
uri = daemon.connect(CalculatorProxy(),'calculapi_%s' % hostname)

print 'Servidor com objeto calculapi_%s esta pronto.' % hostname
daemon.requestLoop()
