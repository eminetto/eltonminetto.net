#!/usr/bin/env python
# -*- coding: ISO-8859-1 -*-

# fazpidist.py 
# author: Mario Olimpio de Menezes 
# date: 11/14/2006
# created to teach distributed computing with Python
# using Pyro - Python Remote Objects
# description and comments in Portuguese
"""  
     Este eh o programa que faz o calculo distribuido.
     O funcionamento eh simples: ha uma classe 'distCalcpi' que
     gerencia o processo; tem um metodo 'connectToNodes' para
     estabelecer a comunicacao com os nodes servidores (que farao
     processamento) e uma classe 'runCalculation' que executara
     as threads criadas atraves da classe 'CalculatorThread'.
     As threads sao necessarias para que a execucao nos nodes seja
     realizada em paralelo.
     O metodo 'runCalculation' espera todas as threads terminarem
     utilizando o metodo 'join' das threads.
"""
""" A ideia de fazer o Monte Carlo distribuido foi retirada do exemplo
     do Prof. Elton Minetto. O original pode ser encontrado em:
     http://www.eltonminetto.net/metodo-de-monte-carlo-distribuido.htm
"""

import time, sys
import Pyro.naming, Pyro.core, Pyro.protocol
import threading

group = ':pidist'  # namespace para o calculo de PI

class distCalcpi:
    def __init__(self,tentativas, nodes):
        self.nodes = nodes
        self.tentativas = tentativas
        self.hitsTot = 0
        self.connectToNodes()

    def connectToNodes(self):
        Pyro.core.initClient()
        Pyro.config.PYRO_NS_DEFAULTGROUP=group
        	# locate the NS
        locator = Pyro.naming.NameServerLocator()
        print 'Procurando Servidores de Nome...',
        ns = locator.getNS()
        print 'Servidor de Nome encontrado em ',ns.URI.address,\
           '('+(Pyro.protocol.getHostname(ns.URI.address) or '??')+') porta',ns.URI.port

        # resolve the Pyro object
        self.pyroNodes = []
        for node in self.nodes:
            #print 'associando a objeto'
            objName = 'calculapi_%s' %node
            try:
                URI=ns.resolve(objName)
                print 'URI:',URI
            except Pyro.core.PyroError,x:
                print 'Couldn\'t bind object, nameserver says:',x
                raise SystemExit
            self.pyroNodes.append(Pyro.core.getProxyForURI(URI))

    def runCalculation(self):
        threads = []
        self.tentativas_por_servidor = int(self.tentativas/(len(self.pyroNodes)))
        for pyroNode in self.pyroNodes:
             try:
                 atual = CalculatorThread(pyroNode,self.tentativas_por_servidor)
                 threads.append(atual)
                 atual.start()
             except:
                 print 'nao foi possivel conectar node ', pyroNode
        for r in threads:
            r.join()
            self.hitsTot += int(r.hits)

class CalculatorThread(threading.Thread):
    def __init__(self, remotecalcpi,tentativas):
        threading.Thread.__init__(self)
        self.remotecalcpi = remotecalcpi
        self.tentativas = tentativas
        self.remotecalcpi.semente(None) # inicializa a semente do gerador aleatorio.
        self.hits = 0
#        print 'remotecalcpi', remotecalcpi, 'tentativas ', self.tentativas
    
    def run(self):
        self.hits = self.remotecalcpi.trials(int(self.tentativas))
        #print 'thread ', self, ' hits: ', self.hits, '\n'
        return self.hits
    

def main(args):
    try:
       tenta = int(args[1])
    except:
       tenta = 1000000
    try:
        if len(args) > 2:
            nodes = args[2:]
    except:
        nodes = ['node1','node2','node3']
    t0 = time.time()
    x = distCalcpi(tenta,nodes)
    x.runCalculation()
    tf = time.time()
    pi = 4.0 * x.hitsTot / tenta
    print 'calculando pi com ' , tenta, ' tentativas\n' 
    print "tempo gasto: ", tf-t0, "seg\n\n"
    print  "Valor calculado: %2.10f \n" %(pi)
   

if __name__ == '__main__':
     main(sys.argv)
