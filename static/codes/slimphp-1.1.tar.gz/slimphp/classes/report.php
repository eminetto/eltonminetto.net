<?php
error_reporting(1);
include("fpdf/fpdf.php");
/** 
  * Classe que define um relatorio
  * Elton Luis Minetto <eminetto at gmail dot com>
  * Francis Perini	<fperini at gmail dot com>
  * Licenca: MIT 
  * @package slimphp
  */
class report extends FPDF
{
	public  $title;
	public  $font;
	
	/**
	* Construtor da classe
	* @param string $title O t�tulo principal do relat�rio
	* @param string $font O tamanho da fonte a ser usada no relat�rio
	* @return void
	*/
	function __construct($title = "",$font = "")
	{
		$this->title = $title;
		if($font == null){
			$font = 6;
		}
		parent::__construct();
		$this->AddPage('L');
		$this->SetFont('Arial','',$font); //tamanho da fonte padr�o para o corpo do PDF
		$this->AliasNbPages();
	}

	/**
	* Gera o cabe�alho do relat�rio
	* @return void
	*/
	function Header()
	{
		//ecolhendo fonte Arial bold 15
		$this->SetFont('Arial','B',8);
		//$this->Cell(151);
		$this->Cell(250);
		$this->Cell(100,10,date("d/m/Y H:j:s"),0,0,'L');		
		$this->Ln(5);
		$this->SetFont('Arial','B',15);
		//Calcula o tamanho do titulo e a posi��o
		$w=$this->GetStringWidth($this->title)+6;
		//$this->SetX((210-$w)/2);
		$this->SetX((300-$w)/2);			
		//$this->Cell(80);
		//Imprimindo um t�tulo
		$this->MultiCell(0,5,$this->title,0,J);
		
		//Quebra de linha
		$this->Ln(5);
	}

	/**
	* Rodap� da p�gina. estamos redefinindo o m�todo Footer da classe pai
	* @return void
	*/	
	function Footer()
	{
		//Posi��o a 1.5 cm do fim da p�gina
		$this->SetY(-15);
		//escolhendo fonte Arial italic 8
		$this->SetFont('Arial','I',8);
		//Numera��o da p�gina
		$this->Cell(0,10,'P�gina '.$this->PageNo().'/{nb}',0,0,'C');
	}
	
	/**
	* M�todo que imprime um texto no relat�rio
	* @param string $contents O texto a ser impresso
	* @return void
	*/		
	function Text($contents)
	{
		$this->MultiCell(0,5,$contents,0,J);
		$this->Ln();
	}
	
	/**
	* Imprime uma tabela no relat�rio
	* @param array $header Um array contendo o cabe�alho da tabela a ser impressa
	* @param array $info Um array contendo os dados a serem impressos
	* @param string $titulo T�tulo da tabela
	* @return void
	*/	
	function Table($header,$info,$titulo)
	{
		//Colors, line width and bold font
		$this->SetFillColor(237,237,237);
		$this->SetTextColor(0);
		$this->SetDrawColor(237,237,237);
		$this->SetLineWidth(.3);
		$this->SetFont('','B');
	     
		$this->Cell(280,7,$titulo,0,3,'C',1);
		$this->Ln();
	
		//conta o numero de elementos em um array
		$itens = count($header);
	   
		//Header
		$largura = 280 / $itens;
		//Monta o Header
		for($i=0;$i<count($header);$i++)  {
			$this->Cell($largura,5,$header[$i],0,0,'L',1);
        }
		$this->Ln();

	    //Color and font restoration
	    $this->SetFillColor(237,237,237);
	    $this->SetTextColor(0);
	    $this->SetFont('');
	    //Data
	    $fill=0;
	    $aux=0;
	    $i=0;
	    
		//Pega os elementos do array na posi��o incial;
		$x = count($header);
		foreach($info as $row) {
			//Monta a linha com o total de informa��es existentes no array, varrendo seus elementos do array  
			while($x != $i){
				$this->Cell($largura,5,$row[$i],0,0,'L',$fill);
				$i++;
			}
			$i=0;

			$this->Ln();
			$fill=!$fill;
		}
	     
	}	
	
	/**
	* Destrutor da classe. Gera a impress�o do relat�rio
	* @return void
	*/	
	function __destruct()
	{
		$this->Output();
	}
}
