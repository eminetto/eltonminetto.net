<?php
/** 
  * Classe generica para trabalhar com tabelas
  * Generic class to work with database tables
  * Elton Luis Minetto <eminetto at gmail dot com>
  * Licenca: MIT 
  * @package slimPHP	
  */

include("adodb/adodb.inc.php"); //a classe depende do adodb. this class needs adodb
include("adodb/adodb-exceptions.inc.php");

class tabela 
{
	/**
	* nome da tabela
	* table name
	* @var string
	*/
	protected $tabela; 

	/**
	* conexao com a base de dados
	* database connection
	* @var string
	*/
	protected $db;
	

	/**
	* array com os dados usados para resultado
	* array used to store the result data
	* @var string[]
	*/
	public $dados_result;

	/**
	* array com os dados usados para insert e update
	* array used to store the insert and update data
	* @var string[]
	*/
	public $dados_dml;

	/**
	* array usado pelo adodb para pegar os resultados das consultas
	* array used by adodb to get query results
	* @var string
	*/
	public $result;
	

	/**
	* array usado para armazenar a descricao da tabela
	* array used to store the table description
	* @var string
	*/
	public $campos;	

	/**
	* string usada para armazenar o comando sql criado
	* string used to store the crated sql query 
	* @var string
	*/
	public $sql;
	
	/**
	* Construtor da classe
	* Class constructor
	* @param string $tabela O nome da tabela. Table name
	* @return void
	*/
	public function __construct($tabela) 
	{
		$this->tabela = $tabela;
		try {
			$this->db = NewADOConnection(app::$db_string);
		} catch (Exception $e) {
			echo "Erro na conexao:".$e->getMessage(); //connection error
		}
		$this->dados_result = array();
		$this->dados_dml = array();
		//cria a descricao da tabela. create the table description
		if(!strpos($this->tabela,',')) {
			$field = $this->db->MetaColumns($tabela);
			//var_dump($field);
			$cont = 0;
			foreach($field as $f) {
				$this->campos[$cont][name] = strtolower($f->name); 
				$this->campos[$cont][type] = strtolower($f->type);
				$this->campos[$cont][not_null] = $f->not_null;
				$this->campos[$cont][auto_increment] = $f->auto_increment;
				$cont++;
			}
		}
	}
	
	
	/**
	* Funcao que altera o valor da propriedade tabela
	* Function that changes the name of the table used
	* @param string $tabela Nome da tabela. Table name
	* @return void
	*/
	public function setTabela($tabela) 
	{
		$this->tabela = $tabela;
	}
	
	/**
	* Funcao que retorna a conexao com a base de dados
	* Funcion that returns the database connection
	* @return db
	*/
	public function getCon() 
	{
		return $this->db;
	}
	/**
	* Funcao que monta a consulta sql para a busca dos dados
	* Funcion that build the sql query used to get the data
	* @param string[] $campos Array com o nome dos campos a serem buscados. An array whit the field names
	* @param string $where Parametros SQL para a pesquisa. SQL query parameters
	* @return void
	*/
	public function get($campos,$where=null,$order=null) 
	{
		//monta o sql. build the sql 
		$this->sql = "select ";
		$this->sql .= implode(",",$campos);
		$this->sql .= " from ".$this->tabela;
		if($where) {
			$this->sql .= " where ".$where;
		}
        if($order) {
            $this->sql .= " order by ".$order;
        }
		try { 
			$this->result = $this->db->Execute($this->sql);
		} catch (Exception $e) {
			echo "Erro na pesquisa:<br>Erro:".$e->getMessage().'<br>SQL:'.$this->sql.'<br><a href="javascript:history.go(-1)">Voltar</a>';//query error
		}
	}

	/**
	* Funcao que retorna um valor booleano indicando se ainda existem resultados
	* Function that verifies if there are more results
	* @return bool
	*/	
	public function result() 
	{
		try {
			if($this->dados_result = @array_change_key_case($this->result->FetchRow(), CASE_LOWER)){ //recebe o array resultante e converte as chaves para minusculo
				return true;	
			}
			else {
				return false;
			}
		} catch (Exception $e)	{
			echo $e->getMessage();
		}
	}


	/**
	* Funcao que faz o insert dos dados na tabela
	* Function that make a insert in the table
	* @return void
	*/
	public function insert() 
	{
		try {
			$this->validate();
		}
		catch (Exception $e) {
			echo $e->getMessage();
			exit;
		}
		$this->db->BeginTrans( );		
		$this->sql = "insert into ".$this->tabela."(";
		$this->sql .= implode(",",array_keys($this->dados_dml));
		$this->sql .= ") values (";
		$this->sql .= implode(",",$this->dados_dml);
		$this->sql .= ')';
		try { 
			$this->result = $this->db->Execute($this->sql);
			$this->dados_dml = array();
		} catch (Exception $e) {
			echo 'Erro na insercao:'.$e->getMessage().'<br><a href="javascript:history.go(-1)">Voltar</a>';//insertion error
			exit;
		}
		
	}
	/**
	* Funcao que faz o update dos dados na tabela
	* Function that make the update
	* @param string $where Parametros SQL para a alteracao. SQL parameters to make the update
	* @return void
	*/
	public function update($where) 
	{
		try {
			$this->validate();
		}
		catch (Exception $e) {
			echo $e->getMessage();
			exit;
		}
		$this->db->BeginTrans( );
		$this->sql = "update ".$this->tabela." set ";
		foreach($this->dados_dml  as $campo => $valor) {
			$this->sql .= "$campo = $valor,";
		}
		$this->sql = substr($this->sql,0,strlen($this->sql)-1);//remove a ultima virgula. removes the comma in the end
		$where = stripslashes($where);
		$this->sql .= " where $where";
		try { 
			$this->result = $this->db->Execute($this->sql);
			$this->dados_dml = array();
		} catch (Exception $e) {
			echo "Erro na atualizacao:<br>SQL:".$this->sql.'<br>Erro:'.$e->getMessage().'<br><a href="javascript:history.go(-1)">Voltar</a>';//update error
			exit;
		}
	}

	/**
	* Funcao que faz a exclusao dos dados na tabela
	* Function that make the delete 
	* @param string $where Parametros SQL para a exclusao. SQL parameters
	* @return void
	*/
	public function delete($where=null) 
	{
		$this->db->BeginTrans( );
		$this->sql = "delete from ".$this->tabela;
		if($where) {
			$this->sql .= " where ".stripslashes($where);
		}
		try { 
			$this->result = $this->db->Execute($this->sql);
		} catch (Exception $e) {
			echo "Erro na exclusao:".$e->getMessage().'<br><a href="javascript:history.go(-1)">Voltar</a>';//delete error
			exit;
		}
	}

	/**
	 * Interceptador __set. Quando um valor eh alterado ele eh colocado no array de dados para ser usado em instrucoes DML (insert, update) 
	 * Interceptor __set. When there is a modification in a field it is sent to an array to be used in DML instructions (insert, delete)
	 * @param string $name Nome do atributo. Attribute's name
	 * @param string $value Valor do atributo. Attribute's value
	 * @return void
	 */
	function __set($name,$value) 
	{
		if(strtolower($value) == 'sysdate') { //resolves oracle sysdate
			$this->dados_dml[$name] = $value;
		}
		else {			
			$this->dados_dml[$name] = "'".$value."'";
		}
	}

	/**
	 * Inserceptador __get. Quando um valor eh solicitado eh entregue o valor do array de resultados das consultas
	 * * Interceptor __get. The value is always in the result array
	 * @param string $name Nome do atributo. Attribute's name
	 * @return string Valor do atributo. Attribute's value.
	 */
	function __get($name) 
	{
		$name = strtolower($name);
		if($name != "dados_result") {
			return $this->dados_result[$name];
		}
		else {
			return $this->dados_result;
		}
	}

	/**
	* Funcao que faz a confirmacao das operacoes
	* Function that confirm the operations
	* @return void
	*/
	public function save() 
	{
		$this->db->CommitTrans( );
	}

	/**
	* Destrutor da classe
	* Class destructor
	* @return void
	*/
	public function __destruct() 
	{
		$this->db->close();
	}
	
	/**
	* Funcao que faz a validacao dos campos
	* Function that make the fields validation
	* @return void
	*/
	public function validate() 
	{
		/* verifica os campos nulos. null fields */
		for($i=0;$i<count($this->campos);$i++) {
			$name = $this->campos[$i][name];
			$valor = $this->dados_dml[$name];
			if($this->campos[$i][not_null] && (!$valor || strlen($valor) == 2) && !$this->campos[$i][auto_increment]) {
				throw new Exception('Campo <b>'.$name. '</b> deve ser inserido<br><a href="javascript:history.go(-1)">Voltar</a>');//field must have a value
			}
		}
		/* verifica o formato dos campos. verifies the fields type*/
		foreach($this->dados_dml  as $campo => $valor) { //cada campo do dml. each field
			if(strlen($valor) > 2) {
				$type = $this->getType($campo);
				switch($type) {
					case "int":
						if(ereg("[_ a-zA-Z]", $valor)) {
							throw new Exception('Campo <b>'.$campo. '</b> deve conter apenas numeros<br><a href="javascript:history.go(-1)">Voltar</a>');//field must have only numbers
						}
						break;	
					case "varchar":
					case "varchar2":
					case "char":
					case "text":
						if(ereg("[#/;]", $valor)) {
							throw new Exception('Campo <b>'.$campo. '</b> possui valores perigosos<br><a href="javascript:history.go(-1)">Voltar</a>');//field have dangerous characters
						}
						break;									
					case "date":
						//formats date from brasilian format to database format
						$year = substr($this->dados_dml[$campo],7,4);
						$month = substr($this->dados_dml[$campo],4,2);
						$day = substr($this->dados_dml[$campo],1,2);
						$hour = substr($this->dados_dml[$campo],12,2);
						$min = substr($this->dados_dml[$campo],15,2);
						$sec = substr($this->dados_dml[$campo],18,2);
						if(!$hour) {
							$this->dados_dml[$campo] = $this->db->DBDate("$year-$month-$day");
						}
						else {
							$this->dados_dml[$campo] = $this->db->DBTimeStamp("$year-$month-$day $hour:$min:$sec");
						}
						break;
				}					
			}
		}
	}
	
	/**
	* Retorna a consula SQL criada
	* Returns the SQL query created
	* @return string
	*/
	public function getSQL() 
	{
		return $this->sql;
	}
    
    /**
	* Retorna todos os dados da consulta
	* @return array
	*/    
    public function getAllData()
	{
        $tmp = array('dados');
        while($this->result()) {
            $tmp['dados'][] = $this->dados_result;        
        }
        return $tmp;
    }
    
	/**
	* Automaticamente seta os valores para a tabela apartir dos dados vindos do $_POST ou $_GET
	* @param array $data Array com os dados. Deve ser o $_GET ou o $_POST
	* @return void
	*/    
    public function setData($data)
	{
		foreach(array_keys($data) as $c) {
			if($this->findField($c)) {
				$this->dados_dml[$c] = "'".$data[$c]."'";
			}
		}
    }
	
	/**
	* Verifica se existe o campo na tabela
	* @param string Nome do campo
	* @return boolean
	*/    	
	private function findField($field) {
		foreach($this->campos as $d) {
			if($d['name'] == $field)
				return true;
		}
		return false;
	}
	
	/**
	* Busca o tipo do campo na tabela
	* @param string Nome do campo
	* @return string Tipo do campo
	*/    
	private function getType($field) {
		foreach($this->campos as $d) {
			if($d['name'] == $field)
				return $d['type'];
		}
		return 'Not Found';
	}
	
}?>
