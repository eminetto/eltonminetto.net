<?php
session_start();
error_reporting(1);
/** 
  * Classe que define uma aplicacao
  * Class that defines an application
  * Elton Luis Minetto <eminetto at gmail dot com>
  * Licenca: MIT 
  * @package slimPHP	
  */
class app 
{
	/**
	* string de conexao com a base de dados
	* database connection sring
	* @var string
	*/
	static $db_string = "";

	/**
	* Construtor da classe
	* Class constructor
	* @return void
	*/
	function __construct($string, $validaSess = 0) 
	{
		//valida sessoes. session validation
		if($validaSess == 1) {
			if($_SESSION[valido] != 1) {
				echo "Sem permissao para acessar";//dont have rigths
				exit;
			}
		}
		
		app::$db_string = $string;
		
		/**
		* O construtor eh resposavel por identificar se alguma funcao foi escolhida pelo usuario e chamar o metodo especifico
		* A variavel 'op' possui o nome da funcao escolhida pelo usuario 
		* The constructor identifies if the user called a funtion and execute it.
		* The 'op' variable have the function called by user
		*/
		
		if(!$_REQUEST[op]) {
			$metodo = 'index'; //funcao padrao. deve estar definida na subclasse. default function. must be defined in a subclass
		}
		else {
			$metodo = $_REQUEST[op];
		}
		/*$classe =  get_class($this); //retorna o nome da classe atual. mesmo se for uma subclasse.return the current class
		if(is_callable(self,"init")){
			$ar = array($classe,"init"); 
			call_user_func($ar);
		}*/
		call_user_func(array($this,$metodo)); //executa o metodo chamado. executes the method
	}
	
	
	/**
	* funcao que mostra a camada de visao
	* function that shows the vision layer of the application
	* @param string $view O nome do arquivo.php que eh a visao. The vision's file name
	* @param string[] $dados Os dados a serem trocados na visao. The vision' data
	* @return void
	*/
	function showView($view, $dados="") 
	{
		if($dados) {
			extract($dados); //transforma cada um dos indices do vetor de dados em variaveis. each array index became a variable 
		}
		include($view);
	}

}
