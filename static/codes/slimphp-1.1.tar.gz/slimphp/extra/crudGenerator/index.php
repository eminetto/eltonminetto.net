<?php
session_start();
include("../../classes/app.php");
include("../../classes/tabela.php");
/** 
  * Objetivo: CrudGenerator 
  * Autor: Elton
  * Data: 03/01/2007
  */

class crudGenerator extends app {
	function index() {
		app::showView("view/index_view.php"); 
	}
	
	function buscaTabelas() {
		$string = "$_POST[driver]://$_POST[usuario]:$_POST[senha]@$_POST[host]";
		if($_POST[database])
			$string .= "/$_POST[database]";
		app::$db_string = $string;
		$_SESSION[db_string] = $string;
		$db = NewADOConnection(app::$db_string);
		$tables = $db->MetaTables('TABLES');
		$i=0;
		foreach($tables as $t) {
			$dados[tabela][$i] = $t;
			$i++;
		}
		app::showView("view/buscaTabelas_view.php",$dados);
		unset($tab);
	}
	
	function buscaCampos() {
		app::$db_string = $_SESSION[db_string];
		$db = NewADOConnection(app::$db_string);
		$colunas = $db->MetaColumns($_POST[tabela]);
		$keys = $db->MetaPrimaryKeys($_POST[tabela]);
		$fKeys = $db->MetaForeignKeys($_POST[tabela]);
		$_SESSION[tabela] = $_POST[tabela];
		$_SESSION[keys] = $keys;		
		$i=0;
		foreach($colunas as $c) {
			$dados[name][$i] = $c->name;
			$dados[type][$i] = $c->type;
			if(in_array($c->name,$keys)) 
				$dados[primary_key][$i] = 1;
			else
				$dados[primary_key][$i] = 0;
			$i++;
		}
		app::showView("view/buscaCampos_view.php",$dados);
	}
	
	function gera() {
		$css = 'view/estilo.css'; //arquivo de estilo a ser criado para a aplica��o 
		$campo_id = $_POST[campo_id];
		$campo_descricao = $_POST[campo_descricao];
		$nome_aplicacao = $_POST[nome_aplicacao];
		if(!$nome_aplicacao)
			$nome_aplicacao = $_SESSION[tabela];
		/* GERANDO INDEX.PHP */
$conteudo_index = '<?
include("../slimphp/classes/app.php");
include("../slimphp/classes/tabela.php");
/** 
  * Objetivo: Crud 
  * Autor: Elton
  * Data: 03/01/2007
  */

class crud'.ucfirst($_SESSION[tabela]).' extends app {
	public function index() {
		$tab = new tabela("'.$_SESSION[tabela].'");
		$tab->get(array("*"));
		$dados = $tab->getAllData();
		unset($tab);
		app::showView("view/index_view.php",$dados);
	}
	
	public function add (){
		if(!$_POST['.$_SESSION[keys][0].']) {
			app::showView("view/add_view.php",$dados);
		}
		else {
			$tab = new tabela("'.$_SESSION[tabela].'");
            $tab->setData($_POST);
			$tab->insert();
			$tab->save();
			unset($tab);
			crud'.ucfirst($_SESSION[tabela]).'::index();
		}
	}
	
	public function edit (){
		$tab = new tabela("'.$_SESSION[tabela].'");	
		if($_GET['.$_SESSION[keys][0].']) { //mostra o formulario
			$tab->get(array("*"), "'.$_SESSION[keys][0].'=$_GET['.$_SESSION[keys][0].']");
            $dados = $tab->getAllData();
			unset($tab);
			app::showView("view/edit_view.php",$dados);			
		}
		elseif ( $_POST['.$_SESSION[keys][0].'] ) { //faz o update
            $tab->setData($_POST);        
			$tab->update("'.$_SESSION[keys][0].'=$_POST['.$_SESSION[keys][0].']");
			$tab->save();
			unset($tab);
			crud'.ucfirst($_SESSION[tabela]).'::index();
		}
	}
	
	public function del (){
		$tab = new tabela("'.$_SESSION[tabela].'");
		$tab->delete("'.$_SESSION[keys][0].'=$_GET['.$_SESSION[keys][0].']");
		$tab->save();
		crud'.$_SESSION[tabela].'::index();
	}
}
$app = new crud'.ucfirst($_SESSION[tabela]).'("'.$_SESSION[db_string].'");
?>
';		
		exec('rm -rf /tmp/crud*');
		mkdir("/tmp/crud");
		//grava conteudo do arquivo index		
		$index = fopen("/tmp/crud/index.php","w");
		fwrite($index, $conteudo_index);
		fclose($index);		
		//cria diretorio das visoes
		mkdir("/tmp/crud/view");
		/* Gerando o cabecalho*/
		$conteudo_header = '<html>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<script language="JavaScript" src="../slimphp/js/ajax.js"></script>
<link href="view/estilo.css" rel="stylesheet" type="text/css"></head>
<body>';
		$header_view = fopen("/tmp/crud/view/header.php","w");
		fwrite($header_view, $conteudo_header);
		fclose($header_view);		


		
		/* GERANDO INDEX_VIEW.PHP */
$conteudo_index_view ='<?php include("header.php");?>
<h2>'.$nome_aplicacao.'</h2>
<p><a href="index.php?op=add">Adicionar</a></p>
<table id="Grid" width="90%" border="0" cellpadding="0" cellspacing="0">
<tr>
';
		for($i=0;$i<count($campo_descricao);$i++) {
			$conteudo_index_view .= '
	<th>'.$campo_descricao[$i].'</th>';
		}
$conteudo_index_view .= '
   <th></th>
   <th></th>
</tr>
<?php 
$i = 0;
foreach($dados as $d) {
	if($i % 2) echo "<tr class=\"L1\">";
	else  echo "<tr class=\"L2\">";
	$i++;
   ?>
';
		for($i=0;$i<count($campo_id);$i++) {
			$conteudo_index_view .= '
	<td><?=$d[\''.$campo_id[$i].'\']?></td>';
		}
$conteudo_index_view .= '
	<td><a href="index.php?op=edit&'.$_SESSION[keys][0].'=<?=$d[\''.$_SESSION[keys][0].'\']?>">Alterar</a></td>
	<td><a href="index.php?op=del&'.$_SESSION[keys][0].'=<?=$d[\''.$_SESSION[keys][0].'\']?>">Excluir</a></td>
   </tr>
   <?
}
?>
</table>
<?php include("footer.php");?>
';		
				
		//grava conteudo do arquivo index_view		
		$index_view = fopen("/tmp/crud/view/index_view.php","w");
		fwrite($index_view, $conteudo_index_view);
		fclose($index_view);		
		/* GERANDO ADD_VIEW.PHP */
$conteudo_add_view ='<?php include("header.php");?>
<h2>'.$nome_aplicacao.' - Adicionar</h2>
<form name="add'.$_SESSION[tabela].'" method="post" action="index.php?op=add">
<table>
';
for($i=0;$i<count($campo_id);$i++) {
	$conteudo_add_view .= '
<tr>
	<td>'.$campo_descricao[$i].'</td>
	<td><input type="text" name="'.$campo_id[$i].'" id="'.$campo_id[$i].'"></td>
</tr>';
	
}
$conteudo_add_view .= '
</table>
<input type="submit" value="Adicionar">
</form>
<p><a href="index.php">Voltar</a></p>
<?php include("footer.php");?>
';
		
		$add_view = fopen("/tmp/crud/view/add_view.php","w");
		fwrite($add_view, $conteudo_add_view);
		fclose($add_view);
		/* GERANDO EDIT_VIEW.PHP */
$conteudo_edit_view ='<?php include("header.php");?>
<h2>'.$nome_aplicacao.' - Alterar</h2>
<form name="edit'.$_SESSION[tabela].'" method="post" action="index.php?op=edit">
<table>
<tr>
   <td></td>
   <td><input type="hidden" name="'.$_SESSION[keys][0].'" id="'.$_SESSION[keys][0].'" value="<?=$dados[0][\''.$_SESSION[keys][0].'\']?>">
   </td>
</tr>
';
for($i=0;$i<count($campo_id);$i++) {
	$conteudo_edit_view .= '
<tr>
   <td>'.$campo_descricao[$i].'</td>
   <td><input type="text" name="'.$campo_id[$i].'" id="'.$campo_id[$i].'" value="<?=$dados[0][\''.$campo_id[$i].'\']?>"></td>
</tr>';
}
$conteudo_edit_view .= '
</table>
<input type="submit" value="Alterar">
</form>
<p><a href="index.php">Voltar</a></p>
<?php include("footer.php");?>
';		
		//echo "<xmp>$conteudo_edit_view</xmp>";
		$edit_view = fopen("/tmp/crud/view/edit_view.php","w");
		fwrite($edit_view, $conteudo_edit_view);
		fclose($edit_view);
		//gerando o rodape
		$conteudo_footer = '
<div id="Rodape">
	<p><a href="http://slimphp.sourceforge.net/"><font size="1">slimPHP</font></a></p>
</div>
</body>
</html>';
		$footer_view = fopen("/tmp/crud/view/footer.php","w");
		fwrite($footer_view, $conteudo_footer);
		fclose($footer_view);			
		
		/* GERANDO ESTILO.CSS */
		$estilo = fopen($css,"r");
		$conteudo_estilo = fread($estilo, filesize($css));
		fclose($estilo);
		$estilo = fopen("/tmp/crud/view/estilo.css","w");
		fwrite($estilo, $conteudo_estilo);
		fclose($estilo);
		
		//compactar
		exec('rm -f ./tmp/crud.zip');
		exec('cp -af ./view/img/ /tmp/crud/view/');
		exec('zip -9 -r /tmp/crud.zip /tmp/crud/*');
		exec('cp /tmp/crud.zip ./tmp/crud.zip');
		echo '<a href="tmp/crud.zip">Download</a><br><br>';
		echo '<a href="index.php">Voltar</a>';
	}//fim da gera��o
}
$app = new crudGenerator();
?>