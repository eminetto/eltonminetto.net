<html>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<script language="JavaScript" src="../slimphp/js/ajax.js"></script>
<link href="view/estilo.css" rel="stylesheet" type="text/css"></head>
<body>
<form action="index.php?op=buscaTabelas" method="post">
<h2>Conexão com o Banco de Dados</h2>
<table>
<tr>
	<td>Driver</td>
	<td>
		<select name="driver">
			<option value="mysql">mysql</option>
			<option value="oci8">oracle</option>
		</select>
	</td>
</tr>
<tr>
	<td>Usuário</td>
	<td><input type="text" name="usuario"></td>
</tr>
<tr>
	<td>Senha</td>
	<td><input type="password" name="senha"></td>
</tr>
<tr>
	<td>Host</td>
	<td><input type="text" name="host"><font size="1">Caso usando Oracle pode ser usado o alias do TNS</font></td>
</tr>
<tr>
	<td>Database</td>
	<td><input type="text" name="database"><font size="1">Não é necessário para Oracle</font></td>
</tr>
</table>
<p><input type="submit" value="Continuar"></p>		
</form>

</body>