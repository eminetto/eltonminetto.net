<html>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<script language="JavaScript" src="../slimphp/js/ajax.js"></script>
<link href="view/estilo.css" rel="stylesheet" type="text/css"></head>
<body>
<form action="index.php?op=gera" method="post">
<h2>Aplicação</h2>
<br>
<table id="Grid" border="0" cellpadding="0" cellspacing="0">
<tr>
	<td><b>Nome da aplicação</b></td>
	<td colspan="4"><input type="text" name="nome_aplicacao"></td>
</tr>
</table>
<br>
<h2>Campos</h2>
<br>
<table id="Grid" width="90%" border="0" cellpadding="0" cellspacing="0">
<?
for($i=0;$i<count($name);$i++) {
?>	
<tr>
	<td><b>Nome</b></td>
	<td><?=$name[$i]?></td>
	<td><b>Tipo</b></td>
	<td><?=$type[$i]?></td>
	<td><b>Descrição</b></td>
	<td>
		<input type="hidden" name="campo_id[<?=$i?>]" value="<?=$name[$i]?>">
		<input type="text" name="campo_descricao[<?=$i?>]">
	</td>
	<td><?if($primary_key[$i]) {?>Chave primária<?}?>&nbsp;</td>
</tr>
<?
}
?>
</table>
<p><input type="submit" value="Continuar"></p>		
</form>

</body>