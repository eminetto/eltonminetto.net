<html>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<script language="JavaScript" src="../slimphp/js/ajax.js"></script>
<link href="view/estilo.css" rel="stylesheet" type="text/css"></head>
<body>
<form action="index.php?op=buscaCampos" method="post">
<h2>Tabela</h2>
<table>
<tr>
	<td>Escolha a tabela</td>
	<td>
		<select name="tabela">
		<?
		for($i=0;$i<count($tabela);$i++) {
		?>
			<option value="<?=$tabela[$i]?>"><?=$tabela[$i]?></option>
		<?
		}
		?>	
		</select>
	</td>
</tr>
</table>
<p><input type="submit" value="Continuar"></p>		
</form>

</body>