<html>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<script language="JavaScript" src="../slimphp/js/ajax.js"></script>
<link href="view/estilo.css" rel="stylesheet" type="text/css"></head>
<body>
<form action="index.php?op=gera" method="post">
<h2>Campos</h2>
<table>
<?
for($i=0;$i<count($name);$i++) {
?>	
<tr>
	<td>Nome</td>
	<td><?=$name[$i]?></td>
</tr>
<?
}
?>
</table>
<p><input type="submit" value="Continuar"></p>		
</form>

</body>